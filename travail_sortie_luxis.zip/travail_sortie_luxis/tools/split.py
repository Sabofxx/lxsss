import re, sys, pathlib
src = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2])
text = src.read_text(encoding='utf-8').replace('\r\n', '\n')
pat = re.compile(r'^===== FICHIER : (.*?) =====$', re.M)
ms = list(pat.finditer(text))
prefix = 'C:\\Users\\padadmin\\Downloads\\reporting\\reporting\\'
for i, m in enumerate(ms):
    p = m.group(1)
    rel = p[len(prefix):] if p.startswith(prefix) else p.replace(':', '')
    body = text[m.end()+1 : ms[i+1].start() if i+1 < len(ms) else len(text)]
    dst = out / pathlib.PurePosixPath(*rel.split('\\'))
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(body, encoding='utf-8')
print(len(ms))
