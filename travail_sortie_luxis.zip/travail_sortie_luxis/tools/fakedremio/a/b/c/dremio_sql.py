import re, sys
sys.path.insert(0, '/Users/cinqtreize-ops/sortie-lxs/source_bundle')
from dremio_sql import read_only_problem
CAT = {
 ("MFGA_INFOCENTRE.DWH","AMS_LOT"): [("C_FUND","CHARACTER VARYING"),("N_LOT","BIGINT"),("D_NAV","DATE"),("C_NAV_TYP","CHARACTER VARYING")],
 ("MFGA_INFOCENTRE.DWH","AMS_MVT"): [("C_FUND","CHARACTER VARYING"),("N_LOT","BIGINT"),("Q_QTY","DECIMAL"),("BADCOL","CHARACTER VARYING")],
 ("MFGI.GTA","REGISTER"): [("REGISTER_ID","INTEGER"),("NAME","CHARACTER VARYING"),("REG_TYPE","CHARACTER VARYING")],
 ("LUXIS.REPADMIN","DWH_AMS_LOT"): [("C_FUND","CHARACTER VARYING"),("N_LOT","BIGINT"),("D_NAV","DATE"),("C_NAV_TYP","CHARACTER VARYING")],
 ("LUXIS.REPADMIN","DWT_GTA_REGISTER"): [("C_N_REGISTER","INTEGER"),("L_NAME","CHARACTER VARYING"),("C_REG_TYP","CHARACTER VARYING"),("N_LOT","BIGINT")],
 ("LUXIS.REPADMIN","NAV"): [("NAV_FUND_NO","CHARACTER VARYING"),("NAV_DATE_NAV","DATE"),("NAV_PUB","CHARACTER VARYING")],
 ("LUXIS.REPADMIN","SOMETHING_ELSE"): [("X","INTEGER")],
}
class Client:
    def __init__(self, env='intg'): self.env=env
    def query(self, sql, max_rows, timeout):
        if 'INFORMATION_SCHEMA."TABLES"' in sql:
            rows=[{"TABLE_SCHEMA":s,"TABLE_NAME":t,"TABLE_TYPE":"TABLE"} for (s,t) in CAT if any(s==r or s.startswith(r+'.') or s.startswith(r) for r in re.findall(r"'([A-Z_]+)[.%']",sql))]
            return 'j',["TABLE_SCHEMA","TABLE_NAME","TABLE_TYPE"],rows,len(rows)
        if 'INFORMATION_SCHEMA."COLUMNS"' in sql:
            sch=re.search(r"TABLE_SCHEMA = '([^']+)'",sql).group(1)
            rows=[{"TABLE_SCHEMA":s,"TABLE_NAME":t,"ORDINAL_POSITION":i+1,"COLUMN_NAME":c,"DATA_TYPE":ty,"NUMERIC_PRECISION":18 if ty=="DECIMAL" else None,"NUMERIC_SCALE":4 if ty=="DECIMAL" else None} for (s,t),cols in CAT.items() if s==sch for i,(c,ty) in enumerate(cols)]
            return 'j',list(rows[0]) if rows else [],rows,len(rows)
        if 'AMS_MVT' in sql and 'APPROX_COUNT_DISTINCT' in sql: raise RuntimeError('job FAILED: function not supported')
        if '"BADCOL"' in sql and 'MIN("BADCOL")' in sql: raise RuntimeError('job FAILED: bad column type')
        aliases=re.findall(r'AS "(\w+)"',sql)
        if aliases==["zz_n"]:
            n=5_000_000 if 'AMS_MVT' in sql and 'zz' in sql else 1000
            return 'j',aliases,[{"zz_n":n}],1
        if aliases and aliases[0]=="zz_n":
            row={a:(1000 if a=='zz_n' else 900 if a.startswith('nn') else 3 if a.startswith('nd') else 'A' if a.startswith('mn') else 'Z') for a in aliases}
            return 'j',aliases,[row],1
        if aliases[:2]==["v","n"]:
            rows=[{"v":"O","n":10},{"v":"P","n":2}]; return 'j',["v","n"],rows,2
        rows=[{"COL1":"Dupont","N":5,"LIBELLE":"x"} for _ in range(min(3,max_rows))]
        return 'j',["COL1","N","LIBELLE"],rows,len(rows)
