# reporting_v2

Rebuild of the LUXIS reports from MFGA_INFOCENTRE / MFGI via Dremio (read-only). Work in progress.

Office PC, current step: see `exchange/explorer/README.md` (run the explorer, then export `from_office.txt`).
