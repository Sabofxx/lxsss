"""Build to_office_NN.txt (this PC -> office PC): office_runtime.py + an embedded, readable payload.

    python make_capsule.py manifest_NN.json            -> exchange/outbox/to_office_NN.txt

manifest_NN.json:
    {"round": "01", "title": "...", "message": "...",
     "files":  {"run_round.py": "../run_round.py", "round_01_requests.txt": "../round_01_requests.txt",
                "reports/": "../../reports"},                      # a folder entry copies the tree
     "steps":  [{"type": "queries", "file": "round_01_requests.txt", "envs": ["ctlq", "intg"]},
                {"type": "cmd", "argv": ["{python}", "run_tests.py", "test_round_01_commands.txt"]}],
     "collect": {"roots": ["Desktop", "Documents", "Downloads"], "patterns": ["*\\\\*.pkb", ...],
                 "skip": ["*\\\\luxrep_exchange*"], "max_depth": 12, "max_mb": 30},
     "bring_back": ["test_round_01_results.txt"]}
Paths in "files" are relative to the manifest. Only text files can be embedded (code, sql, txt, json).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKIP = {"__pycache__", ".pytest_cache", ".git", "out", ".venv", "venv"}


def embed(name: str, text: str) -> list[str]:
    if "\r" in text:
        text = text.replace("\r\n", "\n")
    lines = [f"#|@@FILE {name}"]
    lines += ["#| " + ln for ln in text.split("\n")]
    lines.append("#|@@END")
    return lines


def main(argv=None) -> int:
    mpath = Path((argv or sys.argv[1:])[0]).resolve()
    m = json.loads(mpath.read_text(encoding="utf-8"))
    payload = {}
    for dst, src in m.get("files", {}).items():
        sp = (mpath.parent / src).resolve()
        if dst.endswith("/"):
            for f in sorted(sp.rglob("*")):
                if f.is_file() and not (SKIP & set(f.relative_to(sp).parts)) and f.suffix != ".pyc":
                    payload[dst + f.relative_to(sp).as_posix()] = f.read_text(encoding="utf-8")
        else:
            payload[dst] = sp.read_text(encoding="utf-8")
    meta = {k: v for k, v in m.items() if k != "files"}
    out_lines = [HERE.joinpath("office_runtime.py").read_text(encoding="utf-8").rstrip("\n"), "",
                 "# ==== EMBEDDED PAYLOAD (read by the script above; plain text) ===="]
    out_lines += embed("manifest.json", json.dumps(meta, indent=1, ensure_ascii=False))
    for name, text in payload.items():
        out_lines += embed(name, text)
    outbox = HERE.parent / "outbox"
    outbox.mkdir(exist_ok=True)
    out = outbox / f"to_office_{m['round']}.txt"
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(out_lines) + "\n")
    print(f"{out}  ({out.stat().st_size / 1024:.0f} KB, {len(payload)} files embedded)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
