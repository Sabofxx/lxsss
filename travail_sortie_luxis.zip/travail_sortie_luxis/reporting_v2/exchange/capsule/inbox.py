"""Unpack from_office_NN.txt (office PC -> this PC) into exchange/inbox/NN/.

    python inbox.py /path/to/from_office_01.txt

Writes: status.json, log.txt, every "output <name>" section as <name>, and every packed file under
files/<original path with the drive letter as first folder>, after checking its sha256.
Prints a summary (outputs, files restored, checksum failures).
"""
from __future__ import annotations

import base64
import hashlib
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEAD = re.compile(r"^===== (SECTION|FICHIER BASE64|SKIPPED TOO LARGE) : (.*?) =====$")


def safe_rel(win_path: str) -> Path:
    p = win_path.replace("\\", "/")
    p = re.sub(r"^([A-Za-z]):", r"\1_drive", p).lstrip("/")
    parts = [x for x in p.split("/") if x not in ("", ".", "..")]
    return Path(*parts)


def main(argv=None) -> int:
    src = Path((argv or sys.argv[1:])[0])
    m = re.search(r"from_office_(\w+)", src.name)
    dest = HERE.parent / "inbox" / (m.group(1) if m else src.stem)
    dest.mkdir(parents=True, exist_ok=True)
    lines = src.read_text(encoding="utf-8").split("\n")
    blocks, cur = [], None
    for ln in lines:
        h = HEAD.match(ln)
        if h:
            cur = [h.group(1), h.group(2), []]
            blocks.append(cur)
        elif cur is not None:
            cur[2].append(ln)
    n_out = n_files = 0
    bad, skipped = [], []
    for kind, title, body in blocks:
        if kind == "SECTION":
            name = {"status": "status.json", "log": "log.txt"}.get(title, title.replace("output ", "", 1))
            (dest / name).write_text("\n".join(body).rstrip() + "\n", encoding="utf-8")
            n_out += 1
        elif kind == "FICHIER BASE64":
            path, size, sha = [x.strip() for x in title.split("|")]
            raw = base64.b64decode("".join(body).strip())
            ok = hashlib.sha256(raw).hexdigest() == sha.split()[-1]
            target = dest / "files" / safe_rel(path)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            n_files += 1
            if not ok:
                bad.append(path)
        else:
            skipped.append(title)
    print(f"{src.name} -> {dest}")
    print(f"  sections: {n_out}   files restored: {n_files}   checksum failures: {len(bad)}   too large: {len(skipped)}")
    for b in bad:
        print("  CHECKSUM FAILED:", b)
    for s in skipped:
        print("  TOO LARGE (not packed):", s)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
