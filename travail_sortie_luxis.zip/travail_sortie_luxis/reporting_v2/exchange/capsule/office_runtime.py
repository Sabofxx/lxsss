# ==== LUXREP EXCHANGE CAPSULE ======================================================================
# This .txt file is a Python script. On the office PC, in a terminal:
#
#     python to_office_NN.txt
#
# It never modifies anything outside its own work folder, sends nothing anywhere, and talks to Dremio
# only through dremio_sql.py (read-only guard unchanged). Steps (shown and confirmed one by one):
#   1. unpack the embedded files into .\luxrep_exchange\NN\  (scripts, requests, reports code, ...)
#   2. find dremio_sql.py, check the Dremio sessions (offers `login` if expired)
#   3. run the embedded steps (Dremio queries, tests, ...)
#   4. collect the files asked for (search + your confirmation; nothing is taken without it)
#   5. write ONE file  from_office_NN.txt  next to this capsule: that is the only file to bring back.
# Options: --yes (no confirmation), --skip-queries, --skip-files, --paths my_paths.txt,
#          --roots "C:\dir1;C:\dir2", --client C:\...\dremio_sql.py, --list (show content, run nothing)
# Re-running is safe: answered Dremio queries are cached, the return file is rebuilt.
# The embedded payload is plain text below (lines starting with "#|"), readable before running.
# ===================================================================================================
from __future__ import annotations

import argparse
import base64
import contextlib
import datetime as dt
import fnmatch
import hashlib
import io
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ME = Path(__file__).resolve()


# ------------------------------------------------------------------------------------- payload
def read_payload() -> tuple[dict, dict]:
    files, manifest, cur, buf = {}, {}, None, []
    for line in ME.read_text(encoding="utf-8").splitlines():
        if not line.startswith("#|"):
            continue
        body = line[2:]
        if body.startswith("@@FILE "):
            cur, buf = body[7:].strip(), []
        elif body.startswith("@@END"):
            files[cur] = "\n".join(buf)
            cur = None
        elif cur is not None:
            buf.append(body[1:] if body.startswith(" ") else body)
    manifest = json.loads(files.pop("manifest.json"))
    return manifest, files


# ------------------------------------------------------------------------------------- helpers
class Tee(io.TextIOBase):
    def __init__(self, *streams):
        self.streams = streams

    def write(self, s):
        for st in self.streams:
            try:
                st.write(s)
                st.flush()
            except Exception:
                pass
        return len(s)


def ask(question: str, auto: bool) -> bool:
    if auto:
        print(question + " [auto: yes]")
        return True
    ans = input(question + " [Y/n] ").strip().lower()
    return ans in ("", "y", "yes", "o", "oui")


def find_client(explicit: str | None, work: Path) -> Path | None:
    cands = []
    if explicit:
        cands.append(Path(explicit))
    if os.environ.get("LUXREP_DREMIO_CLIENT"):
        cands.append(Path(os.environ["LUXREP_DREMIO_CLIENT"]))
    for start in (ME.parent, Path.cwd(), work):
        for folder in (start, *start.parents):
            cands.append(folder / "dremio_sql.py")
    home = Path.home()
    for sub in ("Documents", "Desktop", "Downloads"):
        base = home / sub
        if base.is_dir():
            try:
                for p in base.rglob("dremio_sql.py"):
                    cands.append(p)
                    break
            except OSError:
                pass
    for c in cands:
        c = c / "dremio_sql.py" if c.is_dir() else c
        if c.is_file():
            return c.resolve()
    return None


def section(out, title: str, text: str):
    out.write(f"===== SECTION : {title} =====\n{text.rstrip()}\n\n")


def pack_file(out, f: Path, max_mb: float):
    size = f.stat().st_size
    if size > max_mb * 1024 * 1024:
        out.write(f"===== SKIPPED TOO LARGE : {f} | {size} bytes =====\n\n")
        return
    raw = f.read_bytes()
    out.write(f"===== FICHIER BASE64 : {f} | {size} bytes | sha256 {hashlib.sha256(raw).hexdigest()} =====\n")
    b = base64.b64encode(raw).decode("ascii")
    out.write("\n".join(b[i:i + 120] for i in range(0, len(b), 120)) + "\n\n")


def discover(roots: list[Path], patterns: list[str], skip: list[str], max_depth: int) -> list[Path]:
    found = []
    pats = [p.lower() for p in patterns]
    skips = [s.lower() for s in skip]
    for root in roots:
        if not root.is_dir():
            continue
        root_depth = len(root.parts)
        for dirpath, dirnames, filenames in os.walk(root):
            d = Path(dirpath)
            low = str(d).lower().replace("/", "\\")
            if len(d.parts) - root_depth >= max_depth or any(fnmatch.fnmatch(low, s) for s in skips):
                dirnames[:] = []
                continue
            dirnames[:] = [x for x in dirnames if x.lower() not in
                           ("appdata", "__pycache__", ".git", "node_modules", ".venv", "venv", "$recycle.bin")]
            for fn in filenames:
                full = str(d / fn).lower().replace("/", "\\")
                if any(fnmatch.fnmatch(full, p) for p in pats):
                    found.append(d / fn)
    return sorted(set(found))


# ------------------------------------------------------------------------------------- main
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="LuxRep exchange capsule (office side).")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--skip-queries", action="store_true")
    ap.add_argument("--skip-files", action="store_true")
    ap.add_argument("--paths", help="text file, one file or folder per line, to bring back as well")
    ap.add_argument("--roots", help="folders to search, separated by ;")
    ap.add_argument("--client", help="path to dremio_sql.py")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args(argv)

    manifest, files = read_payload()
    nn = manifest["round"]
    print(f"capsule {nn}: {manifest.get('title', '')}")
    print(f"  {len(files)} embedded files, {len(manifest.get('steps', []))} steps, "
          f"{len(manifest.get('collect', {}).get('patterns', []))} file patterns to collect")
    if args.list:
        for name in files:
            print("   file:", name)
        for st in manifest.get("steps", []):
            print("   step:", st)
        return 0

    work = ME.parent / "luxrep_exchange" / nn
    ret = ME.parent / f"from_office_{nn}.txt"
    log_buf = io.StringIO()
    real_out = sys.stdout
    sys.stdout = Tee(real_out, log_buf)
    started = time.time()
    status = {}
    try:
        # 1. unpack
        work.mkdir(parents=True, exist_ok=True)
        for name, text in files.items():
            dst = work / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(text, encoding="utf-8")
        print(f"[1] {len(files)} files unpacked into {work}")
        if manifest.get("message"):
            print("    message: " + manifest["message"])

        # 2. Dremio client and sessions
        client = find_client(args.client, work)
        needs_dremio = any(s["type"] in ("queries", "cmd_dremio") for s in manifest.get("steps", []))
        if client is None and needs_dremio and not args.skip_queries:
            print("[2] dremio_sql.py not found: give its path with --client C:\\...\\dremio_sql.py")
            status["dremio"] = "client not found"
        elif needs_dremio and not args.skip_queries:
            print(f"[2] dremio client: {client}")
            os.environ["LUXREP_DREMIO_CLIENT"] = str(client)
            if len(client.parents) < 4:
                print("    WARNING: dremio_sql.py must sit at least 4 folders deep (it reads parents[3])")
            envs = sorted({e for s in manifest["steps"] for e in s.get("envs", ["ctlq"])})
            for env in envs:
                probe = subprocess.run([sys.executable, str(client), "probe", "--env", env],
                                       capture_output=True, text=True)
                ok = probe.returncode == 0
                print(f"    {env}: {'session OK' if ok else 'session NOT OK: ' + (probe.stderr or probe.stdout).strip()[:200]}")
                if not ok and ask(f"    run `login --env {env}` now?", False if not args.yes else True):
                    subprocess.run([sys.executable, str(client), "login", "--env", env])
                status[f"session_{env}"] = "ok" if ok else "relogged"

        # 3. steps
        for i, st in enumerate(manifest.get("steps", []), 1):
            kind = st["type"]
            if kind in ("queries",) and args.skip_queries:
                print(f"[3.{i}] {kind} skipped (--skip-queries)")
                continue
            if kind == "queries":
                if client is None:
                    print(f"[3.{i}] queries not run: no dremio_sql.py")
                    continue
                print(f"[3.{i}] Dremio queries: {st['file']} (answered ones are cached; Ctrl+C keeps them)")
                cmd = [sys.executable, str(work / "run_round.py"), str(work / st["file"]),
                       "--client", str(client), "--workers", str(st.get("workers", 3))]
                rc = subprocess.run(cmd).returncode
                status[st["file"]] = f"exit {rc}"
            elif kind in ("cmd", "cmd_dremio"):
                print(f"[3.{i}] command: {' '.join(st['argv'])}  (in {work / st.get('cwd', '.')})")
                argv = [sys.executable if a == "{python}" else a for a in st["argv"]]
                rc = subprocess.run(argv, cwd=work / st.get("cwd", ".")).returncode
                status[" ".join(st["argv"])] = f"exit {rc}"

        # 4. files to collect
        chosen: list[Path] = []
        col = manifest.get("collect", {})
        if not args.skip_files and (col.get("patterns") or args.paths):
            if col.get("patterns"):
                roots = ([Path(r) for r in args.roots.split(";") if r.strip()] if args.roots else
                         [Path.home() / x for x in col.get("roots", ["Desktop", "Documents", "Downloads"])])
                print(f"[4] searching {len(col['patterns'])} patterns under: " + "; ".join(map(str, roots)))
                found = discover(roots, col["patterns"], col.get("skip", []), col.get("max_depth", 12))
                found = [f for f in found if work not in f.parents and f != ret and f != ME]
                cand = work / "found_files.txt"
                cand.write_text("# delete a line to leave the file out, add lines (files or folders) to add\n" +
                                "\n".join(str(f) for f in found) + "\n", encoding="utf-8")
                print(f"    {len(found)} files found, list written to {cand}")
                for f in found[:60]:
                    print("      " + str(f))
                if len(found) > 60:
                    print(f"      ... ({len(found) - 60} more in the list file)")
                if not args.yes:
                    input(f"    edit {cand} if needed (Notepad), then press Enter to continue ")
                lines = cand.read_text(encoding="utf-8").splitlines()
                paths = [Path(x.strip()) for x in lines if x.strip() and not x.startswith("#")]
            else:
                paths = []
            if args.paths:
                paths += [Path(x.strip()) for x in Path(args.paths).read_text(encoding="utf-8").splitlines()
                          if x.strip() and not x.startswith("#")]
            for p in paths:
                if p.is_dir():
                    chosen += [f for f in sorted(p.rglob("*")) if f.is_file() and not
                               ({"__pycache__", ".git", "venv", ".venv"} & set(f.parts))]
                elif p.is_file():
                    chosen.append(p)
                else:
                    print(f"    not found, skipped: {p}")
            print(f"[4] {len(chosen)} files will be brought back")

        # 5. return file
        outputs = [work / o for o in manifest.get("bring_back", [])]
        outputs += sorted(work.glob("*_results.txt")) + sorted(work.glob("test_round_*_results.txt"))
        with open(ret, "w", encoding="utf-8", newline="\n") as out:
            out.write(f"# from_office_{nn}  generated {dt.datetime.now().isoformat(timespec='seconds')}  "
                      f"on {os.environ.get('COMPUTERNAME', '?')}  python {sys.version.split()[0]}\n")
            section(out, "status", json.dumps(status, indent=1))
            seen = set()
            for o in outputs:
                if o.is_file() and o not in seen:
                    seen.add(o)
                    section(out, f"output {o.name}", o.read_text(encoding="utf-8", errors="replace"))
            for f in chosen:
                pack_file(out, f, col.get("max_mb", 30))
            section(out, "log", log_buf.getvalue() + f"\nwall_s: {time.time() - started:.0f}")
        mb = ret.stat().st_size / 1024 / 1024
        print(f"[5] DONE -> bring back this ONE file: {ret}  ({mb:.1f} MB)")
    finally:
        sys.stdout = real_out
    return 0


if __name__ == "__main__":
    sys.exit(main())
