"""Run one round of Dremio requests and write a single results file.

Usage (office PC, after `python dremio_sql.py login --env ctlq`, and `--env intg` if the round uses it):

    python run_round.py round_01_requests.txt
    python run_round.py round_01_requests.txt --workers 4 --timeout 900
    python run_round.py round_01_requests.txt --only R01_A001,R01_A002
    python run_round.py round_01_requests.txt --check          (parse + read-only check, no Dremio call)

Request file format (one block per query):

    -- @id: R01_Q001
    -- @purpose: free text
    -- @env: ctlq                 (optional, default ctlq; intg allowed)
    -- @max_rows: 500             (optional, default 500)
    -- @timeout: 600              (optional, seconds)
    SELECT ... ;

Output: <requests>_results.txt next to the requests file (round_01_requests.txt -> round_01_results.txt).
Every finished query is also appended to <results>.cache.jsonl: if the run stops (expired session,
network, Ctrl+C), run the same command again and the queries already answered are not re-run.
Delete the cache file to force a full re-run.

Dependencies: Python 3.9+ standard library and dremio_sql.py (never modified). dremio_sql.py is found via
--client, then the LUXREP_DREMIO_CLIENT environment variable, then by walking up the parent folders of
this script and of the current directory.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import importlib.util
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

DEFAULT_ENV = "ctlq"
DEFAULT_MAX_ROWS = 500
DEFAULT_TIMEOUT = 600
HEADER = re.compile(r"^\s*--\s*@(\w+)\s*:\s*(.*?)\s*$")


# ---------------------------------------------------------------- client loading
def find_client(explicit: str | None) -> Path:
    candidates = []
    if explicit:
        candidates.append(Path(explicit))
    if os.environ.get("LUXREP_DREMIO_CLIENT"):
        candidates.append(Path(os.environ["LUXREP_DREMIO_CLIENT"]))
    for start in (Path(__file__).resolve().parent, Path.cwd().resolve()):
        for folder in (start, *start.parents):
            candidates.append(folder / "dremio_sql.py")
    for c in candidates:
        if c.is_dir():
            c = c / "dremio_sql.py"
        if c.is_file():
            return c.resolve()
    sys.exit("run_round: dremio_sql.py not found (use --client PATH or set LUXREP_DREMIO_CLIENT)")


def load_client(path: Path):
    spec = importlib.util.spec_from_file_location("dremio_sql", path)
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except IndexError:
        sys.exit(f"run_round: {path} must sit at least 4 folders deep (it computes Path(__file__).parents[3])")
    return mod


# ---------------------------------------------------------------- request parsing
def parse_requests(text: str) -> list[dict]:
    blocks, cur = [], None
    for line in text.replace("\r\n", "\n").split("\n"):
        m = HEADER.match(line)
        if m and m.group(1).lower() == "id":
            cur = {"id": m.group(2), "purpose": "", "env": DEFAULT_ENV, "max_rows": DEFAULT_MAX_ROWS,
                   "timeout": None, "sql_lines": []}
            blocks.append(cur)
            continue
        if cur is None:
            continue  # file preamble
        if m and not cur["sql_lines"]:
            key, val = m.group(1).lower(), m.group(2)
            if key in ("max_rows", "timeout"):
                cur[key] = int(val)
            else:
                cur[key] = val
            continue
        cur["sql_lines"].append(line)
    out, seen = [], set()
    for b in blocks:
        sql = "\n".join(b.pop("sql_lines")).strip()
        while sql.endswith(";"):
            sql = sql[:-1].rstrip()
        b["sql"] = sql
        if b["id"] in seen:
            sys.exit(f"run_round: duplicate id {b['id']}")
        seen.add(b["id"])
        out.append(b)
    return out


# ---------------------------------------------------------------- formatting
def cell(v) -> str:
    if v is None:
        return "<null>"
    if isinstance(v, (dict, list)):
        v = json.dumps(v, ensure_ascii=False, sort_keys=True)
    s = str(v)
    return s.replace("\\", "\\\\").replace("|", "\\|").replace("\r", "\\r").replace("\n", "\\n")


def render(req: dict, res: dict) -> str:
    lines = [f"=== {req['id']}",
             f"purpose: {req['purpose']}",
             f"env: {req['env']}   max_rows: {req['max_rows']}   elapsed_s: {res.get('elapsed', 0):.1f}"]
    if res["status"] == "ERROR":
        lines.append("status: ERROR")
        lines.append("error: " + cell(res["error"]))
        lines.append("sql: " + cell(req["sql"]))
    else:
        total, n = res["total"], len(res["rows"])
        trunc = total > n
        lines.append(f"status: OK   rows: {n}   total_rows: {total}" + ("   TRUNCATED" if trunc else ""))
        lines.append("columns: " + " | ".join(cell(c) for c in res["columns"]))
        for r in res["rows"]:
            lines.append(" | ".join(cell(r.get(c)) for c in res["columns"]))
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------- execution
class Runner:
    def __init__(self, mod, timeout_default: int, env_override: str | None):
        self.mod = mod
        self.timeout_default = timeout_default
        self.env_override = env_override
        self.local = threading.local()
        self.auth_failed = threading.Event()

    def client(self, env: str):
        cache = getattr(self.local, "clients", None)
        if cache is None:
            cache = self.local.clients = {}
        if env not in cache:
            cache[env] = self.mod.Client(env=env)
        return cache[env]

    def run(self, req: dict) -> dict:
        env = self.env_override or req["env"]
        req["env"] = env
        if self.auth_failed.is_set():
            return {"status": "SKIPPED"}
        t0 = time.time()
        try:
            job, columns, rows, total = self.client(env).query(
                req["sql"], req["max_rows"], req["timeout"] or self.timeout_default)
            return {"status": "OK", "job": job, "columns": columns, "rows": rows, "total": int(total),
                    "elapsed": time.time() - t0}
        except Exception as exc:  # keep going: one failure never stops the round
            msg = f"{type(exc).__name__}: {exc}"
            if "HTTP 401" in msg or "no Dremio" in msg:
                self.auth_failed.set()
            return {"status": "ERROR", "error": msg, "elapsed": time.time() - t0}


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Run a round of read-only Dremio requests into one results file.")
    p.add_argument("requests", help="round_NN_requests.txt")
    p.add_argument("-o", "--out", help="results file (default: round_NN_results.txt next to the requests)")
    p.add_argument("--client", help="path to dremio_sql.py")
    p.add_argument("--env", choices=["ctlq", "intg"], help="force one environment for every query")
    p.add_argument("--workers", type=int, default=3, help="parallel queries (default 3)")
    p.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="default per-query timeout, seconds")
    p.add_argument("--only", help="comma-separated ids or id prefixes to run")
    p.add_argument("--check", action="store_true", help="parse and check read-only rules only")
    args = p.parse_args(argv)

    req_path = Path(args.requests).resolve()
    reqs = parse_requests(req_path.read_text(encoding="utf-8"))
    if args.only:
        keys = [k.strip() for k in args.only.split(",") if k.strip()]
        reqs = [r for r in reqs if any(r["id"] == k or r["id"].startswith(k) for k in keys)]
    mod = load_client(find_client(args.client))

    bad = [(r["id"], mod.read_only_problem(r["sql"])) for r in reqs]
    bad = [(i, b) for i, b in bad if b]
    if args.check:
        for i, b in bad:
            print(f"REFUSED {i}: {b}")
        print(f"{len(reqs)} requests parsed, {len(bad)} refused by the read-only guard")
        return 1 if bad else 0

    out = Path(args.out).resolve() if args.out else req_path.with_name(
        req_path.name.replace("_requests", "_results") if "_requests" in req_path.name
        else req_path.stem + "_results.txt")
    cache_path = out.with_name(out.name + ".cache.jsonl")
    done = {}
    if cache_path.is_file():
        for line in cache_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                d = json.loads(line)
                if d["result"]["status"] == "OK" and d.get("sql") == next(
                        (r["sql"] for r in reqs if r["id"] == d["id"]), None):
                    done[d["id"]] = d["result"]
    todo = [r for r in reqs if r["id"] not in done]
    print(f"{len(reqs)} requests, {len(done)} already answered (cache), {len(todo)} to run, "
          f"{args.workers} workers -> {out.name}")

    runner = Runner(mod, args.timeout, args.env)
    results = dict(done)
    lock = threading.Lock()
    started = time.time()
    try:
        with cf.ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool, \
                cache_path.open("a", encoding="utf-8") as cache:
            futs = {pool.submit(runner.run, r): r for r in todo}
            for k, f in enumerate(cf.as_completed(futs), 1):
                r, res = futs[f], f.result()
                if res["status"] == "SKIPPED":
                    continue
                with lock:
                    results[r["id"]] = res
                    cache.write(json.dumps({"id": r["id"], "sql": r["sql"], "result": res},
                                           ensure_ascii=False, default=str) + "\n")
                    cache.flush()
                info = (f"{len(res['rows'])}/{res['total']} rows" if res["status"] == "OK"
                        else res["error"][:120])
                print(f"[{k}/{len(todo)}] {r['id']} {res['status']} {info} ({res['elapsed']:.0f}s)", flush=True)
    except KeyboardInterrupt:
        print("interrupted: partial results written; run the same command again to continue")

    ok = sum(1 for r in results.values() if r["status"] == "OK")
    err = sum(1 for r in results.values() if r["status"] == "ERROR")
    trunc = [i for i, r in results.items() if r["status"] == "OK" and r["total"] > len(r["rows"])]
    missing = [r["id"] for r in reqs if r["id"] not in results]
    head = [f"# results of {req_path.name}",
            f"# generated: {dt.datetime.now().isoformat(timespec='seconds')}   wall_s: {time.time() - started:.0f}",
            f"# requests: {len(reqs)}   ok: {ok}   error: {err}   not_run: {len(missing)}   truncated: {len(trunc)}",
            "# cells: <null> = NULL; | \\ newlines are escaped as \\| \\\\ \\n",
            "# truncated ids: " + (", ".join(trunc) or "none"),
            "# error ids: " + (", ".join(i for i, r in results.items() if r["status"] == "ERROR") or "none"),
            "# not run: " + (", ".join(missing) or "none"),
            ""]
    body = [render(r, results[r["id"]]) for r in reqs if r["id"] in results]
    out.write_text("\n".join(head + body), encoding="utf-8")
    print(f"written {out} ({ok} ok, {err} error, {len(missing)} not run)")
    if runner.auth_failed.is_set():
        print("Dremio session refused or expired: run `python dremio_sql.py login --env ctlq` (and intg) "
              "then the same command again; answered queries are kept.")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
