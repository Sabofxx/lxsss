"""Pack files and folders into ONE .txt file that can be carried to the other PC.

    python pack_files.py round_00_files.txt  C:\\path\\to\\folder  C:\\path\\to\\file.xlsx ...
    python pack_files.py round_00_files.txt  @list.txt          (one path per line in list.txt)

Format (same header as the bundles already exchanged):

    ===== FICHIER : <path> =====                  text file, verbatim (utf-8; cp1252 files are decoded)
    ===== FICHIER BASE64 : <path> | <size> bytes | sha256 <hex> =====
                                                  any non-text file (xlsx, xls, csv kept byte-exact, zip...)
    ===== XLSX DUMP : <path> =====                readable dump of an .xlsx: sheets, dimensions, column widths,
                                                  merged cells, then one line per cell:
                                                  <sheet>!<cell> | <type> | <numFmt> | <style id> | <value>

CSV and other report outputs are always sent in BASE64 (exact bytes: encoding, separator, line endings) AND
as text, because the comparison must be byte- and cell-exact. Standard library only; nothing is modified.
Skipped: __pycache__, .git, .venv, node_modules, files above --max-mb (default 25 MB).
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

TEXT_EXT = {".txt", ".md", ".py", ".sql", ".json", ".pks", ".pkb", ".pls", ".plb", ".prc", ".fnc", ".trg", ".vw",
            ".tab", ".ddl", ".wdw", ".wdg", ".wde", ".wdc", ".xml", ".html", ".htm", ".js", ".css", ".ini",
            ".cfg", ".yaml", ".yml", ".toml", ".bat", ".ps1", ".sh", ".log", ".tsv", ".properties"}
EXACT_ALSO_TEXT = {".csv"}               # base64 + text
SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "node_modules", ".pytest_cache", ".mypy_cache"}
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
BUILTIN_FMT = {0: "General", 1: "0", 2: "0.00", 3: "#,##0", 4: "#,##0.00", 9: "0%", 10: "0.00%", 11: "0.00E+00",
               14: "mm-dd-yy", 15: "d-mmm-yy", 16: "d-mmm", 17: "mmm-yy", 18: "h:mm AM/PM", 19: "h:mm:ss AM/PM",
               20: "h:mm", 21: "h:mm:ss", 22: "m/d/yy h:mm", 37: "#,##0 ;(#,##0)", 38: "#,##0 ;[Red](#,##0)",
               39: "#,##0.00;(#,##0.00)", 40: "#,##0.00;[Red](#,##0.00)", 45: "mm:ss", 46: "[h]:mm:ss",
               47: "mmss.0", 48: "##0.0E+0", 49: "@"}


def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace("|", "\\|").replace("\r", "\\r").replace("\n", "\\n")


def decode_text(raw: bytes) -> tuple[str, str]:
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", "replace"), "latin-1"


def xlsx_dump(path: Path) -> list[str]:
    out = []
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
                shared.append("".join(t.text or "" for t in si.iter(f"{{{NS['m']}}}t")))
        fmts, xf_fmt = dict(BUILTIN_FMT), []
        if "xl/styles.xml" in names:
            st = ET.fromstring(z.read("xl/styles.xml"))
            for nf in st.findall("m:numFmts/m:numFmt", NS):
                fmts[int(nf.get("numFmtId"))] = nf.get("formatCode")
            for xf in st.findall("m:cellXfs/m:xf", NS):
                xf_fmt.append(int(xf.get("numFmtId", "0")))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        target = {r.get("Id"): r.get("Target") for r in rels}
        for sh in wb.findall("m:sheets/m:sheet", NS):
            rid = sh.get(f"{{{NS['r']}}}id")
            t = target[rid].lstrip("/")
            t = t if t.startswith("xl/") else "xl/" + t
            root = ET.fromstring(z.read(t))
            sname = sh.get("name")
            dim = root.find("m:dimension", NS)
            out.append(f"# sheet {sname} | state={sh.get('state', 'visible')} | dimension="
                       f"{dim.get('ref') if dim is not None else '?'}")
            for c in root.findall("m:cols/m:col", NS):
                out.append(f"# col {c.get('min')}-{c.get('max')} width={c.get('width')} hidden={c.get('hidden', '0')}")
            for mc in root.findall("m:mergeCells/m:mergeCell", NS):
                out.append(f"# merged {mc.get('ref')}")
            for row in root.findall("m:sheetData/m:row", NS):
                for c in row.findall("m:c", NS):
                    typ, s = c.get("t", "n"), int(c.get("s", "0"))
                    v, f = c.find("m:v", NS), c.find("m:f", NS)
                    if typ == "s" and v is not None:
                        val = shared[int(v.text)]
                    elif typ == "inlineStr":
                        val = "".join(x.text or "" for x in c.iter(f"{{{NS['m']}}}t"))
                    else:
                        val = v.text if v is not None else ""
                    if f is not None:
                        val += f"  [formula: {f.text}]"
                    fmt = fmts.get(xf_fmt[s] if s < len(xf_fmt) else 0, "?")
                    out.append(f"{sname}!{c.get('r')} | {typ} | {esc(str(fmt))} | {s} | {esc(val)}")
    return out


def iter_files(paths: list[str]):
    for p in paths:
        if p.startswith("@"):
            lines = Path(p[1:]).read_text(encoding="utf-8").splitlines()
            yield from iter_files([x.strip() for x in lines if x.strip() and not x.startswith("#")])
            continue
        path = Path(p)
        if path.is_dir():
            for f in sorted(path.rglob("*")):
                if f.is_file() and not (set(f.relative_to(path).parts) & SKIP_DIRS):
                    yield f
        elif path.is_file():
            yield path
        else:
            print(f"pack_files: not found, skipped: {p}", file=sys.stderr)
            yield ("MISSING", p)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Pack files/folders into one .txt for transport.")
    ap.add_argument("output")
    ap.add_argument("paths", nargs="+", help="files, folders, or @list.txt")
    ap.add_argument("--max-mb", type=float, default=25.0)
    args = ap.parse_args(argv)
    n = 0
    with open(args.output, "w", encoding="utf-8", newline="\n") as out:
        out.write("# packed by pack_files.py\n")
        for f in iter_files(args.paths):
            if isinstance(f, tuple):
                out.write(f"===== MISSING : {f[1]} =====\n\n")
                continue
            size = f.stat().st_size
            if size > args.max_mb * 1024 * 1024:
                out.write(f"===== SKIPPED TOO LARGE : {f} | {size} bytes =====\n\n")
                continue
            raw = f.read_bytes()
            ext = f.suffix.lower()
            is_text = ext in TEXT_EXT or (ext == "" and b"\x00" not in raw[:4096])
            if is_text and ext not in EXACT_ALSO_TEXT:
                text, enc = decode_text(raw)
                out.write(f"===== FICHIER : {f} =====\n")
                if enc not in ("utf-8-sig",):
                    out.write(f"# (decoded from {enc})\n")
                out.write(text.replace("\r\n", "\n"))
                out.write("\n\n")
            else:
                out.write(f"===== FICHIER BASE64 : {f} | {size} bytes | sha256 {hashlib.sha256(raw).hexdigest()} =====\n")
                b = base64.b64encode(raw).decode("ascii")
                out.write("\n".join(b[i:i + 120] for i in range(0, len(b), 120)))
                out.write("\n\n")
                if ext in EXACT_ALSO_TEXT:
                    text, enc = decode_text(raw)
                    out.write(f"===== FICHIER : {f} =====\n# (text view, decoded from {enc}; exact bytes above)\n")
                    out.write(text.replace("\r\n", "\n") + "\n\n")
                if ext in (".xlsx", ".xlsm"):
                    try:
                        out.write(f"===== XLSX DUMP : {f} =====\n" + "\n".join(xlsx_dump(f)) + "\n\n")
                    except Exception as exc:  # the base64 copy above stays usable
                        out.write(f"===== XLSX DUMP FAILED : {f} | {exc} =====\n\n")
            n += 1
    print(f"{n} files packed into {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
