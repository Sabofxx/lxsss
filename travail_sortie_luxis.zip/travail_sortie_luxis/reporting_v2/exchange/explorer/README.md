# Dremio explorer (office PC)

Runs several thousand read-only queries on Dremio (catalogue, the 207 targeted requests of round 01,
a profile of every relevant table, LUXIS -> MFGA/MFGI matching). Everything is stored locally in
`explore.db`, then exported to ONE text file, `from_office.txt`, to bring back.

## Steps

1. Download the GitHub repository (Code > Download ZIP) and unzip it at least 4 folders deep, e.g.
   `C:\Users\padadmin\Documents\BA\reporting_v2`. Python 3.9+ and the standard library are enough.
2. Open a terminal in that `reporting_v2` folder and tell the explorer where `dremio_sql.py` is:
   `set LUXREP_DREMIO_CLIENT=C:\...\dremio_sql.py`
3. Sign in to both servers:
   `python C:\...\dremio_sql.py login --env ctlq` then `python C:\...\dremio_sql.py login --env intg`
4. Run (takes hours; it can be stopped and restarted at any time, done queries are kept):
   `python exchange\explorer\explore.py run`
   If the session expires, log in again and run the same command. `python exchange\explorer\explore.py status`
   shows progress. Options: `--max-minutes 120`, `--phase A,B`, `--workers 4`.
5. Export everything to one file, adding the folders still needed (see `exchange\round_00_files_needed.txt`):
   `python exchange\explorer\explore.py export --files C:\...\lxs-apps-oracle C:\...\references C:\...\reports_list.txt`
   (`--files` is optional; folders and single files can be mixed). The result is `reporting_v2\from_office.txt`.
6. Bring `from_office.txt` back.

## Privacy

The export contains table and column names, counts, min/max, codes and verdicts. Rows of register / client /
TA tables are not exported ("client-level rows not exported"), and personal columns (names, addresses, birth
dates, IBAN, ...) are replaced by `#`, including their min/max. The raw results stay in `explore.db`.
