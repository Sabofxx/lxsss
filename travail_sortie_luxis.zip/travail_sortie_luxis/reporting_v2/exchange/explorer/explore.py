"""Dremio explorer for the LUXIS exit (office PC). Thousands of read-only queries, results kept locally,
a short photo-friendly summary on screen.

    python explore.py run                 all phases (resumable: re-run = continue), default 4 workers
    python explore.py run --phase A,B     only some phases;  --max-minutes 240 to stop in time
    python explore.py status              progress per phase
    python explore.py pages               summary pages to PHOTOGRAPH (Enter = next, b = back, 12 = go to page 12, q = quit)
    python explore.py pages --section S4  one section only;  --lines 55 --width 150 to fit the screen
    python explore.py source --root C:\\...\\lxs-apps-oracle      pages of the LUXIS source still needed
    python explore.py export [--files DIR ...]  ONE .txt with every result (+ optional files) to bring back
    python explore.py sql R01_P004        show one query and its stored result (local only, not for photos)

Phases (each one generated from what the previous ones found):
    A  catalogue: tables + columns (with precision/scale) of MFGA_INFOCENTRE, MFGI, LUXIS, BUSINESS, ...
    B  the 207 targeted requests of round 01 (../round_01_requests.txt)
    C  profile of every relevant table: row counts (CTLQ and INTG), per-column non-null / approx distinct /
       min / max, value lists of code columns, 5-row samples (kept local), presence of the reference funds
    D  LUXIS -> MFGA/MFGI matching: candidate pairs by name and column overlap, then fingerprints of both
       sides on the same slice, compared column by column (also detects renamed columns)
Everything is stored in explore.db (SQLite, next to this script). Nothing leaves the PC except
from_office.txt (explore.py export). The pages and the export never show client data: in register/client/TA tables, and for personal columns
(names, addresses, birth dates, IBAN, ...) values are masked; only names of tables/columns, counts,
codes and verdicts are printed.

dremio_sql.py: --client PATH, else LUXREP_DREMIO_CLIENT, else the parent folders. Standard library only.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import importlib.util
import json
import os
import re
import sqlite3
import sys
import threading
import time
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB_PATH = HERE / "explore.db"
REQ01 = HERE.parent / "round_01_requests.txt"

# ------------------------------------------------------------------------------------------ scope
CATALOG_ROOTS = ["MFGA_INFOCENTRE", "MFGI", "LUXIS", "BUSINESS", "FRI", "STAGGING", "MFGA"]
COLUMN_ROOTS = ["MFGA_INFOCENTRE", "MFGI", "LUXIS.REPADMIN", "LUXIS.EFRONT", "BUSINESS.FUND_ACCOUNTING"]
# every REPADMIN object the reports read (PKG_LUXREP_QUERIES + GL / FNP / conso projects)
LUXIS_TARGETS = """BILL_LISTE_PARTS BILL_OP_LIST CFA_RECON_SFI_FA COMPARTMENT DOC_NUM_CDE_TBL_DESCR DOC_NUM_ENTITE
DOC_NUM_RELATION DOC_NUM_RELATION_DETAIL DWH_AMS_CASH_MVT DWH_AMS_DEAL_COUPON_DIVIDEND DWH_AMS_DEAL_FUTURE
DWH_AMS_DEAL_OPTION DWH_AMS_DEAL_STOCK_MARKET DWH_AMS_EQUI_FONDS DWH_AMS_FUTURES_MASTER DWH_AMS_HIS_PTF_FRX_RATES
DWH_AMS_HIS_PTF_VAL DWH_AMS_LOT DWH_AMS_MVT DWH_AMS_NAV_ARC_PNL_DELTA DWH_AMS_NAV_ARC_RESULT DWH_AMS_OPTIONS_MASTER
DWH_AMS_PORTFOLIO DWH_AMS_SEC_INTL_ID DWH_AMS_SEC_MASTER DWH_AMS_ACC_POS DWH_AMS_ACC_DEF DWH_AMS_ACC_LINK_CHARTS
DWT_GTA_CLIENT DWT_GTA_COLL_ACCOUNT DWT_GTA_FUNDS DWT_GTA_FUND_DELAYDATE DWT_GTA_MESSAGE DWT_GTA_NAV_SHARE_PRICE
DWT_GTA_PTF_SHARE DWT_GTA_REGISTER DWT_GTA_REG_CONTRACT DWT_GTA_SEC_INTL_ID DWT_GTA_SEC_MASTER DWT_GTA_TFC
DWT_GTA_ADRESSES_ELEC FONDS_TIERS_PUB_V2 FUND LUXREP_ENVOI LUXREP_QUERIES_FONDS LUXREP_QUERIES_FUTUR_ACCOUNT
LUXREP_QUERIES_GROUPE_EXCLU LUXREP_QUERIES_GROUPE_FONDS LUXREP_QUERIES_GROUPE_UMBRELLA LUXREP_SETUP_DO_CLASS
LUXREP_SETUP_EF_CODE_OPE LUXREP_TA_CODE_OPE LUXREP_TA_CODE_OPE_SETUP LUXREP_TA_PENDING LUXREP_TA_REGISTRES
LUXREP_TA_REGISTRES_BLOCKED LUXREP_TB_FONDS MESI_TRANSACTION_L001 MFFA_REP_PARAM_REPORT MF_CHARGES MF_GRP_MULTICLASS
NAV NAV_PARTS NAV_PARTS_MULTI_CCY OP_TA OP_TA_ARC POS_TA POS_TA_ARC RELATION_ADRESSAGE REPORT_DEFINITION SHARECLASS
TAB_FND_CPT_AVQ TAB_FND_MAIN TAB_FND_MAIN_BCK TAB_FND_STRUCT TA_POSITIONS TURNOVER_CORRESP_NUM_FA_TA
V_FUND_BACKDATED_FLAG V_DWT_GTA_FUND_DELAYDATE WEBSERVICE_DATA WKF_EVENTS WKF_FULL_DETAILS_FACTU GLOBAL_VAR
FUND_PTF_CONSO TBL_TFM FUND_POOL_REPARTITION FUND_BILAN_FONDS FUND_CONSO_LISTE FUND_BILAN_DET FUND_BILAN_ACC
FUND_BILAN_ACC_DET FUND_BILAN_ACC_CONSO FUND_BILAN_CONSO_METHOD FNP_PARAM_PLAN_CPT FNP_PARAM_RUB FNP_PARAM_FONDS
FNP_PARAM_PARTS FNP_PARAM_NAV_INI FNP_PARAM_FREQ MFFA_REP_NAV MFFA_REP_NAV_MULTI_CCY MFFA_REP_NAV_PART
GAIN_SECURITIES""".split()
LUXIS_TARGET_PREFIXES = ("WRK_QUERIES_", "LUXREP_", "FNP_", "MFFA_REP_", "FUND_BILAN", "DWT_GTA_", "DWH_AMS_")
USED_MFGA = set("""AMS_LOT AMS_MVT AMS_CASH_MVT AMS_SECURITIES_INTL_ID AMS_SECURITIES_MASTER AMS_PORTFOLIO
AMS_FUTURES_MASTER AMS_MESSAGE AMS_OPTIONS_MASTER AMS_DEAL_COUPON_DIVIDEND AMS_DEAL_STOCK_MARKET AMS_DEAL_OPTION
AMS_DEAL_FUTURE AMS_HIS_PTF_FRX_RATES AMS_HIS_PTF_VAL_POOL AMS_ACC_POS AMS_PTF_SHARE AMS_HIS_PTF_VAL AMS_ACC_DEF
AMS_NAV_ARC_SHARE_DETAIL AMS_NAV_ARC_MULTI_CCY AMS_ACC_LINK_CHARTS AMS_NAV_ARC_RESULT AMS_NAV_ARC_PNL_DELTA
AMS_EQUI_FONDS AMS_POOL_MASTER_LINK AMS_POOL_DETAIL_LINK AMS_NAV_ARC_MULTI_CLASS AMS_CORRESPONDENTS_MASTER
AMS_CORR_CUSTOMERS AMS_PTF_MANAGER AMS_NAV_ARC_SDNAR02""".split())
USED_MFGA_PREFIXES = ("AMS_NAV_ARC", "AMS_HIS_", "AMS_DEAL_", "AMS_POOL", "AMS_FUND", "AMS_SHARE", "AMS_PTF_")
MFGI_KEYWORDS = r"(REGIST|CLIENT|CONTRACT|PTF_SHARE|FUND|NAV|PRICE|COLL|MESSAGE|CODESMSG|SEC_|TFC|DELAY|POSITION|DEAL|ORDER|TRANS|OPER|MOVE|SHARE|ACCOUNT|BLOCK)"
MFGA_PROFILE_SCHEMAS = ["MFGA_INFOCENTRE.DWH", "MFGA_INFOCENTRE.REPADMIN", "MFGA_INFOCENTRE.EFRONT"]
REF_FUNDS = ["280287", "280299", "812645", "280499", "242013", "280421", "280273", "280274", "280268", "280605",
             "241582", "282303", "280334", "523379", "784810", "472863", "352745", "305093", "258815", "745635",
             "745642", "231433", "200815"]
LOT_WINDOW = (8554978, 8607153)          # CTLQ, 2026-06-01 .. 2026-07-01 (proven in luxrep_reports)
DATE_WINDOW = ("2026-06-01", "2026-07-01")
FULL_SCAN_MAX_ROWS = 3_000_000           # above: profile on a slice
SLICE_LIMIT = 500_000
TOPVAL_MAX_DISTINCT = 60
TOPVAL_MAX_COLS = 40
CHUNK_COLS = 30
KEY_HINTS = ["C_FUND", "N_LOT", "D_NAV", "C_SUB_FUND", "C_SHARE", "C_SRV", "N_ENTRY", "N_ENTRY_PTF", "C_N_ID", "C_CCY",
             "FA_NUM", "NAV_FUND_NO", "NAV_DATE_NAV", "NAP_FUND_NO", "C_N_REGISTER", "C_N_CLIENT", "C_TABLE",
             "C_ELEMENT", "C_LNG", "N_LINE", "C_N_ACC"]

# ------------------------------------------------------------------------------------------ privacy
SENSITIVE_TABLE = re.compile(r"(REGISTER|CLIENT|ADRESS|ADDRESS|CONTRACT|COLL_ACC|OP_TA|POS_TA|TA_POSITIONS|"
                             r"LUXREP_TA_|WRK_QUERIES_TA_|DOC_NUM|MESI_|INVESTOR|HOLDER|PERSON|CONTACT|PENDING|"
                             r"BLOCKED|MAIL|PHONE|SHAREHOLDER|ACCOUNT_INVESTOR|KYC|BENEF)", re.I)
PERSONAL_COL = re.compile(r"(FIRST|ADDR|ADRES|STREET|RUE|ZIP|POSTAL|MAIL|PHONE|TEL|FAX|IBAN|BIC|SWIFT|ACC_NO|BIRTH|"
                          r"NAISS|NATIONAL|PASSPORT|TAX_ID|TIN|SSN|CONTACT|COMMENT|REMARK|NOTE|LASTNAME|SURNAME)", re.I)
NAMEY_COL = re.compile(r"(NAME|NOM|LIB|LABEL|L_|CITY|VILLE|CLIENT|HOLDER)", re.I)


def masked(table: str, col: str) -> bool:
    if PERSONAL_COL.search(col or ""):
        return True
    return bool(SENSITIVE_TABLE.search(table or "")) and bool(NAMEY_COL.search(col or ""))


# ------------------------------------------------------------------------------------------ helpers
def qid_quote(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def path_quote(schema: str, table: str) -> str:
    return ".".join(qid_quote(p) for p in schema.split(".")) + "." + qid_quote(table)


def short_type(t: str, p, s) -> str:
    t = (t or "").upper()
    m = {"CHARACTER VARYING": "V", "VARCHAR": "V", "CHAR": "C", "CHARACTER": "C", "INTEGER": "I", "INT": "I",
         "BIGINT": "BI", "SMALLINT": "SI", "DOUBLE": "F8", "FLOAT": "F4", "REAL": "F4", "DATE": "DT",
         "TIMESTAMP": "TS", "TIME": "TM", "BOOLEAN": "BO", "DECIMAL": "D", "NUMERIC": "D", "VARBINARY": "BIN"}
    k = m.get(t, t[:6])
    if k == "D" and p is not None:
        return f"D{p},{s if s is not None else 0}"
    return k


def profilable(t: str) -> bool:
    t = (t or "").upper()
    return not any(x in t for x in ("BOOLEAN", "BINARY", "STRUCT", "LIST", "MAP", "ARRAY", "UNION", "INTERVAL", "NULL"))


def fmt_val(v, width=22) -> str:
    if v is None:
        return "-"
    if isinstance(v, float):
        s = repr(v) if abs(v) < 1e15 else f"{v:.6g}"
    else:
        s = str(v)
    s = s.replace("\n", " ").replace("\r", " ")
    return s if len(s) <= width else s[:width - 1] + "~"


# ------------------------------------------------------------------------------------------ store
class Store:
    def __init__(self, path: Path):
        self.con = sqlite3.connect(str(path), check_same_thread=False)
        self.con.execute("""CREATE TABLE IF NOT EXISTS q (id TEXT PRIMARY KEY, phase TEXT, purpose TEXT, env TEXT,
            sql TEXT, status TEXT, columns TEXT, rows TEXT, total INTEGER, error TEXT, elapsed REAL, ts TEXT,
            meta TEXT)""")
        self.con.commit()
        self.lock = threading.Lock()

    def done(self, qid: str, sql: str) -> bool:
        r = self.con.execute("SELECT status, sql FROM q WHERE id = ?", (qid,)).fetchone()
        return bool(r) and r[0] == "OK" and r[1] == sql

    def save(self, item: dict, res: dict):
        with self.lock:
            self.con.execute("INSERT OR REPLACE INTO q VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                item["id"], item["phase"], item.get("purpose", ""), item["env"], item["sql"], res["status"],
                json.dumps(res.get("columns")), json.dumps(res.get("rows"), default=str), res.get("total"),
                res.get("error"), res.get("elapsed"), dt.datetime.now().isoformat(timespec="seconds"),
                json.dumps(item.get("meta", {}), default=str)))
            self.con.commit()

    def get(self, qid: str):
        r = self.con.execute("SELECT status, columns, rows, total, error, meta, sql, purpose, env FROM q WHERE id = ?",
                             (qid,)).fetchone()
        if not r:
            return None
        return {"status": r[0], "columns": json.loads(r[1] or "null"), "rows": json.loads(r[2] or "null"),
                "total": r[3], "error": r[4], "meta": json.loads(r[5] or "{}"), "sql": r[6], "purpose": r[7],
                "env": r[8]}

    def ids(self, prefix: str) -> list[str]:
        return [r[0] for r in self.con.execute("SELECT id FROM q WHERE id LIKE ? ORDER BY id", (prefix + "%",))]

    def stats(self):
        return self.con.execute("SELECT phase, status, COUNT(*), SUM(elapsed) FROM q GROUP BY phase, status "
                                "ORDER BY phase, status").fetchall()


# ------------------------------------------------------------------------------------------ dremio
def load_client(explicit: str | None):
    cands = [Path(explicit)] if explicit else []
    if os.environ.get("LUXREP_DREMIO_CLIENT"):
        cands.append(Path(os.environ["LUXREP_DREMIO_CLIENT"]))
    for start in (HERE, Path.cwd()):
        cands += [f / "dremio_sql.py" for f in (start, *start.parents)]
    for c in cands:
        c = c / "dremio_sql.py" if c.is_dir() else c
        if c.is_file():
            spec = importlib.util.spec_from_file_location("dremio_sql", c)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            print(f"dremio client: {c}")
            return mod
    sys.exit("explore: dremio_sql.py not found (--client PATH or LUXREP_DREMIO_CLIENT)")


class Runner:
    def __init__(self, mod, store: Store, workers: int, deadline: float | None):
        self.mod, self.store, self.workers, self.deadline = mod, store, workers, deadline
        self.local = threading.local()
        self.auth_failed = threading.Event()

    def _client(self, env):
        cache = getattr(self.local, "c", None)
        if cache is None:
            cache = self.local.c = {}
        if env not in cache:
            cache[env] = self.mod.Client(env=env)
        return cache[env]

    def _one(self, item):
        if self.auth_failed.is_set() or (self.deadline and time.time() > self.deadline):
            return None
        problem = self.mod.read_only_problem(item["sql"])
        if problem:
            return {"status": "ERROR", "error": "refused by guard: " + problem, "elapsed": 0}
        t0 = time.time()
        try:
            job, cols, rows, total = self._client(item["env"]).query(item["sql"], item.get("max_rows", 500),
                                                                     item.get("timeout", 600))
            return {"status": "OK", "columns": cols, "rows": rows, "total": int(total), "elapsed": time.time() - t0}
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"
            if "HTTP 401" in msg or "no Dremio" in msg:
                self.auth_failed.set()
            return {"status": "ERROR", "error": msg[:1500], "elapsed": time.time() - t0}

    def run(self, items: list[dict], label: str):
        todo = [i for i in items if not self.store.done(i["id"], i["sql"])]
        print(f"  {label}: {len(items)} queries, {len(items) - len(todo)} already done, {len(todo)} to run", flush=True)
        if not todo:
            return
        n_ok = n_err = 0
        t0 = time.time()
        with cf.ThreadPoolExecutor(max_workers=self.workers) as pool:
            futs = {pool.submit(self._one, i): i for i in todo}
            for k, f in enumerate(cf.as_completed(futs), 1):
                item, res = futs[f], f.result()
                if res is None:
                    continue
                self.store.save(item, res)
                n_ok += res["status"] == "OK"
                n_err += res["status"] == "ERROR"
                if k % 25 == 0 or k == len(todo):
                    print(f"    {k}/{len(todo)}  ok {n_ok}  error {n_err}  {time.time() - t0:.0f}s", flush=True)
        if self.auth_failed.is_set():
            raise SystemExit("Dremio session expired: run `python dremio_sql.py login --env ctlq` (and intg), "
                             "then the same command again (done queries are kept).")
        if self.deadline and time.time() > self.deadline:
            raise SystemExit("time limit reached: run the same command again to continue.")


# ------------------------------------------------------------------------------------------ catalogue access
class Catalog:
    def __init__(self, store: Store):
        self.tables = {}     # (schema, table) -> type
        self.cols = {}       # (schema, table) -> [(name, type, p, s)]
        for qid in store.ids("A_TAB_"):
            r = store.get(qid)
            if r and r["status"] == "OK":
                for row in r["rows"]:
                    self.tables[(row["TABLE_SCHEMA"], row["TABLE_NAME"])] = row.get("TABLE_TYPE")
        for qid in store.ids("A_COL_"):
            r = store.get(qid)
            if r and r["status"] == "OK":
                for row in r["rows"]:
                    k = (row["TABLE_SCHEMA"], row["TABLE_NAME"])
                    self.cols.setdefault(k, []).append((int(row["ORDINAL_POSITION"] or 0), row["COLUMN_NAME"],
                                                        row["DATA_TYPE"], row.get("NUMERIC_PRECISION"),
                                                        row.get("NUMERIC_SCALE")))
        for k in self.cols:
            self.cols[k] = [c[1:] for c in sorted(self.cols[k])]

    def colnames(self, key):
        return [c[0] for c in self.cols.get(key, [])]

    def find(self, schema: str, table: str):
        for k in self.tables:
            if k[0].upper() == schema.upper() and k[1].upper() == table.upper():
                return k
        for k in self.cols:
            if k[0].upper() == schema.upper() and k[1].upper() == table.upper():
                return k
        return None


# ------------------------------------------------------------------------------------------ phase A
def phase_a(run: Runner):
    items = []
    for root in CATALOG_ROOTS:
        items.append({"id": f"A_TAB_{root}", "phase": "A", "env": "ctlq", "max_rows": 200000, "timeout": 1800,
                      "purpose": f"tables under {root}",
                      "sql": f"""SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA."TABLES"
WHERE TABLE_SCHEMA = '{root}' OR TABLE_SCHEMA LIKE '{root}.%'"""})
    items.append({"id": "A_TAB_INTG_MFGA_INFOCENTRE", "phase": "A", "env": "intg", "max_rows": 200000,
                  "timeout": 1800, "purpose": "tables on INTG (MFGA_INFOCENTRE + MFGI + LUXIS)",
                  "sql": """SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA."TABLES"
WHERE TABLE_SCHEMA LIKE 'MFGA_INFOCENTRE%' OR TABLE_SCHEMA LIKE 'MFGI%' OR TABLE_SCHEMA LIKE 'LUXIS%'"""})
    run.run(items, "A1 catalogue")
    schemas = set()
    for root in CATALOG_ROOTS:
        r = run.store.get(f"A_TAB_{root}")
        if r and r["status"] == "OK":
            schemas |= {row["TABLE_SCHEMA"] for row in r["rows"]}
    wanted = sorted(s for s in schemas if any(s == c or s.startswith(c + ".") for c in COLUMN_ROOTS))
    items = []
    for s in wanted:
        items.append({"id": f"A_COL_{s}", "phase": "A", "env": "ctlq", "max_rows": 600000, "timeout": 1800,
                      "purpose": f"columns of every table in {s}",
                      "sql": f"""SELECT TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE,
       NUMERIC_PRECISION, NUMERIC_SCALE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
FROM INFORMATION_SCHEMA."COLUMNS" WHERE TABLE_SCHEMA = '{s}'"""})
    run.run(items, f"A2 columns ({len(wanted)} schemas)")


# ------------------------------------------------------------------------------------------ phase B
def parse_requests(path: Path) -> list[dict]:
    out, cur = [], None
    head = re.compile(r"^\s*--\s*@(\w+)\s*:\s*(.*?)\s*$")
    for line in path.read_text(encoding="utf-8").split("\n"):
        m = head.match(line)
        if m and m.group(1) == "id":
            cur = {"id": m.group(2), "phase": "B", "env": "ctlq", "max_rows": 500, "timeout": 900, "lines": []}
            out.append(cur)
        elif cur is not None and m and not cur["lines"]:
            k, v = m.group(1), m.group(2)
            cur[k] = int(v) if k in ("max_rows", "timeout") else v
        elif cur is not None:
            cur["lines"].append(line)
    for c in out:
        c["sql"] = "\n".join(c.pop("lines")).strip().rstrip(";").strip()
    return out


def phase_b(run: Runner):
    if not REQ01.is_file():
        print(f"  B skipped: {REQ01} not found")
        return
    run.run(parse_requests(REQ01), "B round 01 targeted requests")


# ------------------------------------------------------------------------------------------ phase C
def profile_targets(cat: Catalog) -> list[tuple[str, str]]:
    keys = []
    for (s, t) in cat.cols:
        su, tu = s.upper(), t.upper()
        if su == "LUXIS.REPADMIN" and (tu in LUXIS_TARGETS or tu.startswith(LUXIS_TARGET_PREFIXES)):
            keys.append((s, t))
        elif su in [x.upper() for x in MFGA_PROFILE_SCHEMAS]:
            keys.append((s, t))
        elif su.startswith("MFGI"):
            keys.append((s, t))
        elif su == "BUSINESS.FUND_ACCOUNTING":
            keys.append((s, t))
    return sorted(set(keys))


def slug(s: str, t: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", f"{s}__{t}")


def source_expr(cat: Catalog, key, count) -> tuple[str, str]:
    """FROM expression (full table or a slice) and a label."""
    full = path_quote(*key)
    cols = {c.upper(): c for c in cat.colnames(key)}
    if count is not None and count <= FULL_SCAN_MAX_ROWS:
        return full, "full"
    conds, label = [], []
    if "N_LOT" in cols and "C_FUND" in cols:
        conds.append(f"{qid_quote(cols['N_LOT'])} > {LOT_WINDOW[0]} AND {qid_quote(cols['N_LOT'])} <= {LOT_WINDOW[1]}")
        label.append("lots Jun26")
    elif "D_NAV" in cols:
        conds.append(f"{qid_quote(cols['D_NAV'])} > DATE '{DATE_WINDOW[0]}' AND {qid_quote(cols['D_NAV'])} <= DATE '{DATE_WINDOW[1]}'")
        label.append("dnav Jun26")
    if "C_FUND" in cols and count is not None and count > 50 * FULL_SCAN_MAX_ROWS:
        conds.append(f"CAST({qid_quote(cols['C_FUND'])} AS VARCHAR) IN ({','.join(repr(f) for f in REF_FUNDS)})")
        label.append("ref funds")
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    return f"(SELECT * FROM {full}{where} LIMIT {SLICE_LIMIT}) zz", "slice:" + ("+".join(label) or "first rows") + f"<= {SLICE_LIMIT}"


def stats_sql(src: str, cols: list[tuple], distinct: bool) -> str:
    parts = ['COUNT(*) AS "zz_n"']
    for i, (name, _t, _p, _s) in enumerate(cols):
        q = qid_quote(name)
        parts += [f'COUNT({q}) AS "nn_{i}"', f'MIN({q}) AS "mn_{i}"', f'MAX({q}) AS "mx_{i}"']
        if distinct:
            parts.append(f'APPROX_COUNT_DISTINCT({q}) AS "nd_{i}"')
    return "SELECT " + ", ".join(parts) + f" FROM {src}"


def phase_c(run: Runner):
    store = run.store
    cat = Catalog(store)
    keys = profile_targets(cat)
    print(f"  C: {len(keys)} tables to profile")
    # C1 row counts (CTLQ + INTG for the report tables)
    items = []
    for k in keys:
        items.append({"id": f"C1_{slug(*k)}", "phase": "C", "env": "ctlq", "max_rows": 1, "timeout": 600,
                      "purpose": f"row count {k[0]}.{k[1]}", "meta": {"key": k},
                      "sql": f'SELECT COUNT(*) AS "zz_n" FROM {path_quote(*k)}'})
        if k[0].upper() == "LUXIS.REPADMIN" or k[0].upper() == "MFGA_INFOCENTRE.DWH":
            items.append({"id": f"C1I_{slug(*k)}", "phase": "C", "env": "intg", "max_rows": 1, "timeout": 600,
                          "purpose": f"row count on INTG {k[0]}.{k[1]}", "meta": {"key": k},
                          "sql": f'SELECT COUNT(*) AS "zz_n" FROM {path_quote(*k)}'})
    run.run(items, "C1 row counts")
    counts = {}
    for k in keys:
        r = store.get(f"C1_{slug(*k)}")
        counts[k] = int(r["rows"][0]["zz_n"]) if r and r["status"] == "OK" and r["rows"] else None
    # C2 column stats by chunk (with approx distinct, fallback without)
    items, plan = [], {}
    for k in keys:
        src, label = source_expr(cat, k, counts[k])
        cols = [c for c in cat.cols[k] if profilable(c[1])]
        plan[k] = (src, label, cols)
        for ci in range(0, len(cols), CHUNK_COLS):
            chunk = cols[ci:ci + CHUNK_COLS]
            items.append({"id": f"C2_{slug(*k)}_{ci // CHUNK_COLS}", "phase": "C", "env": "ctlq", "max_rows": 1,
                          "timeout": 900, "purpose": f"column stats {k[0]}.{k[1]} [{label}]",
                          "meta": {"key": k, "label": label, "cols": [c[0] for c in chunk]},
                          "sql": stats_sql(src, chunk, True)})
        items.append({"id": f"C5_{slug(*k)}", "phase": "C", "env": "ctlq", "max_rows": 5, "timeout": 600,
                      "purpose": f"5-row sample {k[0]}.{k[1]} (local only)", "meta": {"key": k},
                      "sql": f"SELECT * FROM {src} LIMIT 5" if src.startswith("(") else f"SELECT * FROM {src} LIMIT 5"})
        names = {c.upper(): c for c in cat.colnames(k)}
        if "C_FUND" in names:
            cf_ = qid_quote(names["C_FUND"])
            extra = f', MIN({qid_quote(names["N_LOT"])}) AS "lot_min", MAX({qid_quote(names["N_LOT"])}) AS "lot_max"' \
                if "N_LOT" in names else ""
            items.append({"id": f"C6_{slug(*k)}", "phase": "C", "env": "ctlq", "max_rows": 100, "timeout": 900,
                          "purpose": f"reference funds present in {k[0]}.{k[1]}", "meta": {"key": k},
                          "sql": f"SELECT CAST({cf_} AS VARCHAR) AS \"fund\", COUNT(*) AS \"n\"{extra} FROM {path_quote(*k)} "
                                 f"WHERE CAST({cf_} AS VARCHAR) IN ({','.join(repr(f) for f in REF_FUNDS)}) GROUP BY 1"})
    run.run(items, "C2 column stats + C5 samples + C6 reference funds")
    retry = []
    for it in items:
        if not it["id"].startswith("C2_"):
            continue
        r = store.get(it["id"])
        if r and r["status"] == "ERROR":
            k = tuple(it["meta"]["key"])
            src, label, cols = plan[k]
            chunk = [c for c in cols if c[0] in it["meta"]["cols"]]
            retry.append(dict(it, id=it["id"].replace("C2_", "C2B_"), sql=stats_sql(src, chunk, False),
                              purpose=it["purpose"] + " (no approx distinct)"))
    run.run(retry, "C2B stats retry without approx distinct")
    single = []
    for it in retry:
        r = store.get(it["id"])
        if r and r["status"] == "ERROR":
            k = tuple(it["meta"]["key"])
            src, label, cols = plan[k]
            for c in [c for c in cols if c[0] in it["meta"]["cols"]]:
                single.append({"id": f"C2C_{slug(*k)}_{re.sub(r'[^A-Za-z0-9]', '_', c[0])}", "phase": "C",
                               "env": "ctlq", "max_rows": 1, "timeout": 600, "purpose": f"single column stats {c[0]}",
                               "meta": {"key": k, "label": label, "cols": [c[0]]},
                               "sql": stats_sql(src, [c], False)})
    run.run(single, "C2C single-column stats (isolating failing columns)")
    # C4 value lists of code columns
    prof = collect_profiles(store)
    items = []
    for k in keys:
        src, label, cols = plan[k]
        lows = [c for c, st in prof.get(k, {}).items()
                if st.get("nd") is not None and 0 < st["nd"] <= TOPVAL_MAX_DISTINCT and not PERSONAL_COL.search(c)]
        for c in lows[:TOPVAL_MAX_COLS]:
            q = qid_quote(c)
            items.append({"id": f"C4_{slug(*k)}_{re.sub(r'[^A-Za-z0-9]', '_', c)}", "phase": "C", "env": "ctlq",
                          "max_rows": TOPVAL_MAX_DISTINCT + 1, "timeout": 900, "meta": {"key": k, "col": c, "label": label},
                          "purpose": f"values of {k[1]}.{c} [{label}]",
                          "sql": f'SELECT {q} AS "v", COUNT(*) AS "n" FROM {src} GROUP BY {q} ORDER BY 2 DESC LIMIT {TOPVAL_MAX_DISTINCT + 1}'})
    run.run(items, "C4 value lists of code columns")


def collect_profiles(store: Store) -> dict:
    prof = {}
    for prefix in ("C2_", "C2B_", "C2C_"):
        for qid in store.ids(prefix):
            r = store.get(qid)
            if not r or r["status"] != "OK" or not r["rows"]:
                continue
            k = tuple(r["meta"]["key"])
            row = r["rows"][0]
            d = prof.setdefault(k, {})
            for i, c in enumerate(r["meta"]["cols"]):
                cur = d.setdefault(c, {"label": r["meta"].get("label")})
                cur["n"] = row.get("zz_n")
                cur["nn"] = row.get(f"nn_{i}")
                cur["mn"] = row.get(f"mn_{i}")
                cur["mx"] = row.get(f"mx_{i}")
                if row.get(f"nd_{i}") is not None:
                    cur["nd"] = row.get(f"nd_{i}")
    return prof


# ------------------------------------------------------------------------------------------ phase D
def candidate_pairs(cat: Catalog, counts: dict) -> list[tuple]:
    lux = [k for k in cat.cols if k[0].upper() == "LUXIS.REPADMIN" and
           (k[1].upper() in LUXIS_TARGETS or k[1].upper().startswith(LUXIS_TARGET_PREFIXES))]
    oth = [k for k in cat.cols if k[0].upper().startswith(("MFGA_INFOCENTRE.", "MFGI"))]
    oth_sets = {k: {c.upper() for c in cat.colnames(k)} for k in oth}
    pairs = []
    for L in lux:
        ls = {c.upper() for c in cat.colnames(L)}
        name = L[1].upper()
        scored = []
        for M, ms in oth_sets.items():
            j = len(ls & ms) / max(1, len(ls | ms))
            mn = M[1].upper()
            rule = (name.startswith("DWH_AMS_") and mn == name[4:]) or \
                   (name.startswith("DWH_AMS_") and mn == name[4:].replace("SEC_", "SECURITIES_")) or \
                   (name.startswith("DWT_GTA_") and M[0].upper().startswith("MFGI") and
                    (mn == name[8:] or mn.startswith(name[8:]) or name[8:].startswith(mn))) or \
                   (mn == name and not M[0].upper().startswith("MFGA_INFOCENTRE.DWH"))
            if rule or j >= 0.25:
                scored.append((1.0 if rule else 0.0, j, M))
        scored.sort(key=lambda x: (-x[0], -x[1]))
        for r_, j, M in scored[:4]:
            pairs.append((L, M, round(j, 3), bool(r_)))
    return pairs


def common_slice(cat: Catalog, L, M, counts) -> tuple[str, str, str] | None:
    lc = {c.upper(): c for c in cat.colnames(L)}
    mc = {c.upper(): c for c in cat.colnames(M)}
    funds = ",".join(repr(f) for f in REF_FUNDS)
    if "C_FUND" in lc and "C_FUND" in mc and "N_LOT" in lc and "N_LOT" in mc:
        w = lambda c: (f"WHERE CAST({qid_quote(c['C_FUND'])} AS VARCHAR) IN ({funds}) AND {qid_quote(c['N_LOT'])} > "
                       f"{LOT_WINDOW[0]} AND {qid_quote(c['N_LOT'])} <= {LOT_WINDOW[1]}")
        return w(lc), w(mc), "ref funds + lots Jun26"
    if "C_FUND" in lc and "C_FUND" in mc:
        w = lambda c: f"WHERE CAST({qid_quote(c['C_FUND'])} AS VARCHAR) IN ({funds})"
        return w(lc), w(mc), "ref funds"
    nl, nm = counts.get(L), counts.get(M)
    if nl is not None and nm is not None and nl <= 20_000_000 and nm <= 20_000_000:
        return "", "", "full tables"
    return None


def phase_d(run: Runner):
    store = run.store
    cat = Catalog(store)
    counts = {}
    for k in cat.cols:
        r = store.get(f"C1_{slug(*k)}")
        counts[k] = int(r["rows"][0]["zz_n"]) if r and r["status"] == "OK" and r["rows"] else None
    pairs = candidate_pairs(cat, counts)
    bad_cols = set()
    for qid in store.ids("C2C_"):
        r = store.get(qid)
        if r and r["status"] == "ERROR":
            bad_cols.add((tuple(r["meta"]["key"]), r["meta"]["cols"][0]))
    print(f"  D: {len(pairs)} candidate pairs LUXIS -> MFGA/MFGI ({len(bad_cols)} unprofilable columns left out)")
    items = []
    for L, M, j, rule in pairs:
        sl = common_slice(cat, L, M, counts)
        if sl is None:
            continue
        pid = f"{slug(*L)}__TO__{slug(*M)}"
        for side, key, where in (("L", L, sl[0]), ("M", M, sl[1])):
            cols = [c for c in cat.cols[key] if profilable(c[1]) and (tuple(key), c[0]) not in bad_cols]
            for ci in range(0, len(cols), CHUNK_COLS):
                chunk = cols[ci:ci + CHUNK_COLS]
                parts = ['COUNT(*) AS "zz_n"']
                for i, (name, t, _p, _s) in enumerate(chunk):
                    q = qid_quote(name)
                    parts += [f'COUNT({q}) AS "nn_{i}"', f'COUNT(DISTINCT {q}) AS "nd_{i}"', f'MIN({q}) AS "mn_{i}"',
                              f'MAX({q}) AS "mx_{i}"']
                items.append({"id": f"D_{pid}_{side}{ci // CHUNK_COLS}", "phase": "D", "env": "ctlq", "max_rows": 1,
                              "timeout": 900, "purpose": f"fingerprint {side} {key[1]} [{sl[2]}]",
                              "meta": {"pair": [list(L), list(M)], "side": side, "key": key, "cols": [c[0] for c in chunk],
                                       "slice": sl[2], "jaccard": j, "rule": rule},
                              "sql": "SELECT " + ", ".join(parts) + f" FROM {path_quote(*key)} {where}"})
    run.run(items, "D fingerprints of candidate pairs")


def fingerprints(store: Store) -> dict:
    out = {}
    for qid in store.ids("D_"):
        r = store.get(qid)
        if not r or r["status"] != "OK" or not r["rows"]:
            continue
        m = r["meta"]
        pk = (tuple(m["pair"][0]), tuple(m["pair"][1]))
        d = out.setdefault(pk, {"L": {}, "M": {}, "slice": m["slice"], "jaccard": m["jaccard"], "rule": m["rule"]})
        row = r["rows"][0]
        for i, c in enumerate(m["cols"]):
            d[m["side"]][c] = (row.get("zz_n"), row.get(f"nn_{i}"), row.get(f"nd_{i}"), str(row.get(f"mn_{i}")),
                               str(row.get(f"mx_{i}")))
    return out


def compare_pair(fp: dict) -> dict:
    L, M = fp["L"], fp["M"]
    nL = next(iter(L.values()))[0] if L else None
    nM = next(iter(M.values()))[0] if M else None
    same, diff, renamed = [], [], []
    for c, sig in L.items():
        if c in M:
            (same if sig[1:] == M[c][1:] else diff).append(c)
    used = set(same)
    for c, sig in L.items():
        if c in same or sig[1] in (0, None) or (sig[2] is not None and sig[2] < 2) or sig[3] == sig[4]:
            continue
        hits = [mc for mc, ms in M.items() if mc not in used and ms[1:] == sig[1:] and mc != c]
        if len(hits) == 1:
            renamed.append((c, hits[0]))
            used.add(hits[0])
    return {"nL": nL, "nM": nM, "same": same, "diff": diff, "renamed": renamed, "nLcols": len(L), "nMcols": len(M)}


# ------------------------------------------------------------------------------------------ pages
class Pager:
    def __init__(self, width: int, lines: int):
        self.width, self.lines = width, lines
        self.sections = []           # (code, title, [lines])

    def add(self, code: str, title: str, lines: list[str]):
        self.sections.append((code, title, lines))

    def build(self, only: str | None = None) -> list[list[str]]:
        pages = []
        stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        body_h = self.lines - 2
        for code, title, lines in self.sections:
            if only and code not in only.split(","):
                continue
            wrapped = []
            for ln in lines:
                while len(ln) > self.width - 4:
                    wrapped.append(ln[:self.width - 4])
                    ln = "  " + ln[self.width - 4:]
                wrapped.append(ln)
            chunks = [wrapped[i:i + body_h] for i in range(0, max(1, len(wrapped)), body_h)] or [[]]
            for ci, ch in enumerate(chunks):
                pages.append((code, title, ci + 1, len(chunks), ch))
        out = []
        for n, (code, title, ci, cn, ch) in enumerate(pages, 1):
            head = f"PAGE {n:03d}/{len(pages):03d}  {code} {title} ({ci}/{cn})  {stamp}"
            body = [f"{ln:<{self.width - 4}}|{line_crc(ln)}" for ln in ch]
            out.append([head, "-" * (self.width)] + body)
        return out


def line_crc(ln: str) -> str:
    """2-hex checksum of the line without any whitespace (robust to spaces lost on a photo)."""
    bare = re.sub(r"\s", "", ln)
    return "%02x" % (zlib.crc32(bare.encode("utf-8")) & 0xff)


def esc_cell(v, table, col, width=20):
    if masked(table, col):
        return "#"
    return fmt_val(v, width)


def build_pages(store: Store, width: int, lines: int) -> Pager:
    pg = Pager(width, lines)
    cat = Catalog(store)
    # S1 status
    st = ["phase status  n  seconds"] + [f"{p:<5} {s:<6} {n:>6} {int(e or 0):>8}" for p, s, n, e in store.stats()]
    for env in ("ctlq", "intg"):
        r = store.get("R01_M02" + ("3" if env == "ctlq" else "4"))
        if r and r["status"] == "OK" and r["rows"]:
            st.append(f"freshness {env}: " + ", ".join(f"{k}={fmt_val(v, 25)}" for k, v in r["rows"][0].items()))
    pg.add("S1", "RUN STATUS", st)
    # S2 catalogue per schema
    per = {}
    for (s, t), typ in cat.tables.items():
        per.setdefault(s, [0, 0])
        per[s][0 if (typ or "").upper().startswith("TABLE") else 1] += 1
    s2 = ["schema  tables  views"] + [f"{s}  {a}  {b}" for s, (a, b) in sorted(per.items())]
    intg = store.get("A_TAB_INTG_MFGA_INFOCENTRE")
    if intg and intg["status"] == "OK":
        intg_set = {(r["TABLE_SCHEMA"], r["TABLE_NAME"]) for r in intg["rows"]}
        miss = sorted(f"{s}.{t}" for (s, t) in cat.tables if s.upper().startswith(("MFGA_INFOCENTRE", "MFGI", "LUXIS.REPADMIN"))
                      and (s, t) not in intg_set and (t.upper() in LUXIS_TARGETS or s.upper().startswith(("MFGA_INFOCENTRE.DWH", "MFGI"))))
        s2.append(f"on CTLQ but not on INTG ({len(miss)}): " + ", ".join(miss[:300]))
    pg.add("S2", "CATALOGUE", s2)
    # S3 errors (all phases, compact)
    errs = store.con.execute("SELECT id, error FROM q WHERE status = 'ERROR' ORDER BY id").fetchall()
    s3 = [i + ": " + re.sub(r"\s+", " ", e or "")[:width - len(i) - 8] for i, e in errs[:600]]
    pg.add("S3", f"ERRORS ({len(errs)})", s3 or ["none"])
    # S4 round 01 digests
    s4 = []
    skip_rows = re.compile(r"^R01_(A00[1-4]|C00\d)$")
    caps = {"P": 400, "W": 3, "N": 60, "B": 40, "F": 45, "D": 15, "G": 30, "R": 5, "M": 25, "E": 20, "X": 40, "A": 60}
    for qid in store.ids("R01_"):
        r = store.get(qid)
        sens = bool(SENSITIVE_TABLE.search(r["sql"] or ""))
        s4.append(f"== {qid} [{r['status']}] {r['purpose'][:width - 30]}")
        if r["status"] != "OK":
            s4.append("   err: " + re.sub(r"\s+", " ", r["error"] or "")[:width - 12])
            continue
        cols = r["columns"] or []
        s4.append(f"   rows {len(r['rows'] or [])}/{r['total']}  cols: " + ",".join(cols))
        if skip_rows.match(qid):
            continue
        cap = caps.get(qid[4], 15)
        tbl = "SENSITIVE" if sens else ""
        aggregate = bool(re.search(r"\b(GROUP\s+BY|COUNT\s*\(|SUM\s*\(|LISTAGG)", r["sql"] or "", re.I)) and \
            not re.search(r"\bSELECT\s+(\w+\.)?\*", r["sql"] or "", re.I)
        if sens and not aggregate:
            zz = {c: v for c, v in ((r["rows"] or [{}])[0] if r["rows"] else {}).items() if c.upper().startswith("ZZ_")}
            s4.append("   (client-level rows not shown) " + " ".join(f"{c}={fmt_val(v)}" for c, v in zz.items()))
            continue
        for row in (r["rows"] or [])[:cap]:
            cells = []
            for c in cols:
                v = row.get(c)
                if sens and not isinstance(v, (int, float)) and not re.match(r"^(N|NB|COUNT|ZZ_|N_|LOT|MIN|MAX)", c, re.I):
                    cells.append("#")
                else:
                    cells.append(esc_cell(v, tbl, c))
            s4.append("   " + "|".join(cells))
        if len(r["rows"] or []) > cap:
            s4.append(f"   ... {len(r['rows']) - cap} more rows (local)")
    pg.add("S4", "ROUND 01 RESULTS", s4 or ["phase B not run"])
    # S5 columns of the tables that matter
    prof = collect_profiles(store)
    paired = {M for (_L, M) in fingerprints(store)}
    keys = [k for k in cat.cols if (k[0].upper() == "LUXIS.REPADMIN" and k[1].upper() in LUXIS_TARGETS)
            or (k[0].upper() == "LUXIS.REPADMIN" and k[1].upper().startswith(("WRK_QUERIES_", "LUXREP_")))
            or (k[0].upper() == "MFGA_INFOCENTRE.DWH" and (k[1].upper() in USED_MFGA or
                                                         k[1].upper().startswith(USED_MFGA_PREFIXES)))
            or (k[0].upper().startswith("MFGI") and re.search(MFGI_KEYWORDS, k[1], re.I))
            or k in paired]
    s5 = []
    for k in sorted(keys):
        r = store.get(f"C1_{slug(*k)}")
        ri = store.get(f"C1I_{slug(*k)}")
        n = r["rows"][0]["zz_n"] if r and r["status"] == "OK" and r["rows"] else "?"
        ni = ri["rows"][0]["zz_n"] if ri and ri["status"] == "OK" and ri["rows"] else "-"
        cols = ", ".join(f"{c} {short_type(t, p, s)}" for c, t, p, s in cat.cols[k])
        s5.append(f"{k[0]}.{k[1]} rows={n} intg={ni}: {cols}")
    pg.add("S5", "COLUMNS (name type; V varchar, D p,s decimal, DT date, TS timestamp)", s5)
    # S6 code values
    s6 = []
    for qid in store.ids("C4_"):
        r = store.get(qid)
        if not r or r["status"] != "OK":
            continue
        k, c = tuple(r["meta"]["key"]), r["meta"]["col"]
        if not (k[0].upper() in ("LUXIS.REPADMIN", "MFGA_INFOCENTRE.DWH") or k[0].upper().startswith("MFGI")):
            continue
        rows = r["rows"] or []
        vals = ",".join(f"{'#' if masked(k[1], c) else fmt_val(x['v'], 14)}={x['n']}" for x in rows[:TOPVAL_MAX_DISTINCT])
        s6.append(f"{k[1]}.{c}{'+' if len(rows) > TOPVAL_MAX_DISTINCT else ''}: {vals}")
    pg.add("S6", "CODE VALUES (value=count, on profile scope)", s6 or ["phase C not run"])
    # S7 matching
    s7 = []
    for (L, M), fp in sorted(fingerprints(store).items()):
        cp = compare_pair(fp)
        ren = ",".join(f"{a}>{b}" for a, b in cp["renamed"])
        s7.append(f"{L[1]} -> {M[0]}.{M[1]} [{fp['slice']}] rows {cp['nL']}/{cp['nM']} jac {fp['jaccard']} "
                  f"same {len(cp['same'])}/{cp['nLcols']} diff {len(cp['diff'])}"
                  + (f" diffcols:{','.join(cp['diff'][:25])}" if cp["diff"] else "") + (f" renamed:{ren}" if ren else ""))
    pg.add("S7", "LUXIS -> MFGA/MFGI MATCHING (same = identical count/distinct/min/max)", s7 or ["phase D not run"])
    # S8 profiles of the LUXIS targets and their MFGA twins (one line per table)
    s8 = []
    for k in sorted(keys):
        p = prof.get(k, {})
        if not p:
            continue
        label = next(iter(p.values())).get("label")
        nulls = [c for c, v in p.items() if v.get("nn") == 0]
        lot = p.get("N_LOT") or {}
        dn = p.get("D_NAV") or {}
        s8.append(f"{k[1]} [{label}] n={next(iter(p.values())).get('n')} lot {lot.get('mn')}..{lot.get('mx')} "
                  f"dnav {fmt_val(dn.get('mn'), 10)}..{fmt_val(dn.get('mx'), 10)} empty cols: {','.join(nulls[:40])}")
    pg.add("S8", "PROFILES (scope, lots, NAV dates, always-empty columns)", s8 or ["phase C not run"])
    # S9 every table name (to ask for more columns next time)
    s9 = []
    for root in ("MFGA_INFOCENTRE", "MFGI", "BUSINESS", "FRI", "LUXIS.EFRONT"):
        names = []
        for (s, t) in sorted(cat.tables):
            if s == root or s.startswith(root + "."):
                r = store.get(f"C1_{slug(s, t)}")
                n = r["rows"][0]["zz_n"] if r and r["status"] == "OK" and r["rows"] else ""
                names.append(f"{s[len(root) + 1:] + '.' if s != root else ''}{t}{'=' + str(n) if n != '' else ''}")
        if names:
            s9.append(f"[{root}] " + " ".join(names))
    pg.add("S9", "ALL TABLE NAMES (name=rows when profiled)", s9 or ["phase A not run"])
    return pg


def show_pages(pages: list[list[str]], start: int = 1):
    i = max(0, start - 1)
    while 0 <= i < len(pages):
        os.system("cls" if os.name == "nt" else "clear")
        print("\n".join(pages[i]))
        ans = input("[Enter] next  [b] back  [number] go to  [q] quit > ").strip().lower()
        if ans == "q":
            break
        if ans == "b":
            i -= 1
        elif ans.isdigit():
            i = int(ans) - 1
        else:
            i += 1


# ------------------------------------------------------------------------------------------ LUXIS source pages
SOURCE_NAMES = """GET_BLOOMBERG_TICKER GET_CALCUL_TYPE_FUTUR GET_CCY_INFO GET_CODE_CODE GET_CODE_ISIN_FROM_SEC
GET_CODE_ISIN_FROM_SEC_TA GET_CODE_ISIN_FROM_TK GET_COMPARTIMENT_CCY GET_DATE_NAV_FOR_PRICE_OPE_TA
GET_DATE_NAV_WITH_DATE_PUB GET_DATE_NAV_WITH_LOT GET_DATE_POSITION_TA GET_DATE_PUB_WITH_DATE_NAV GET_DATE_TA_TYPE
GET_DET_TX_DET_BY_DATE GET_DWH_MESSAGE GET_DWT_GTA_MESSAGE GET_DWT_MESSAGE GET_DWT_MESSAGE_ABREGE GET_EFRONT_DATE
GET_EFRONT_OPE_NAME GET_FUND_CCY GET_FUND_CCY_TB_FDS GET_FUND_NAME_TB_FDS GET_FUND_NAV_BACKDATED
GET_FUND_NB_DECIMALES GET_FUND_NUM_FA_REF GET_FUND_NUM_POOL GET_FUND_TYPE GET_GLOBAL_VAR_VALUE
GET_LAST_DATE_NAV_POS_TA_EFRONT GET_LAST_DATE_POSITION_TA GET_LAST_TRADE_DATE_TA GET_LIB_CPT_BILAN GET_LOT_DATE_NAV
GET_NAV_DATE_CALCUL GET_NAV_DATE_NAV GET_NAV_DATE_NAV_PUBLIEE_PS GET_NAV_FIRST_DATE_NAV GET_PERIOD_SUB_RED
GET_PRICE_FA_PART GET_PRICE_FA_PART_CCY GET_PRICE_TRADE_DATE_TA GET_PUID_MF GET_QUARTER GET_QUOTATION_PLACE
GET_RATIO_ALLOCATION GET_REGISTRE_TA_LIBELLE GET_REGISTRE_TA_STP GET_SEC_CCY GET_SEC_INTL_ID GET_SEC_NAME
GET_TA_REG_NAME GET_TNA_FDS GET_TNA_FDS_TOT_LIVE GET_TNA_FDS_TOT_TA GET_TNA_RATIO_CLASS_Z
GET_UNDERLYING_CODE_INTERNE_FA GET_UNDERLYING_CODE_SERVICE GET_X_RATE_EF GET_X_RATE_FOR_NAV_MF GET_X_RATE_MFTA
GET_X_RATE_MF_2 GET_X_RATE_MF_CM CHAINE_NETTOIE V_FUND_BACKDATED_FLAG V_DWT_GTA_FUND_DELAYDATE LUXREP_TB_FONDS
GET_DATE_PERIOD GET_PLAN_COMPTABLE_FOND GET_DATE_NAV_LAST_CLOSING GET_IS_EFRONT_SUBFUND""".split()
LOADED_TABLES = ["NAV", "NAV_PARTS", "NAV_PARTS_MULTI_CCY", "OP_TA", "OP_TA_ARC", "POS_TA", "POS_TA_ARC",
                 "TA_POSITIONS", "LUXREP_TB_FONDS", "TAB_FND_MAIN", "TAB_FND_MAIN_BCK", "TURNOVER_CORRESP_NUM_FA_TA",
                 "LUXREP_TA_REGISTRES", "LUXREP_TA_REGISTRES_BLOCKED", "LUXREP_TA_CODE_OPE", "CFA_RECON_SFI_FA",
                 "FONDS_TIERS_PUB_V2", "WEBSERVICE_DATA", "TAB_FND_CPT_AVQ", "GLOBAL_VAR", "FUND_POOL_REPARTITION"]


def compact_plsql(text: str) -> list[str]:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    out = []
    for ln in text.splitlines():
        ln = re.sub(r"--.*$", "", ln).rstrip()
        if not ln.strip():
            continue
        ind = len(ln) - len(ln.lstrip())
        out.append(" " * min(ind // 2, 8) + re.sub(r"\s+", " ", ln.strip()))
    return out


def source_pages(root: Path, width: int, lines: int, names_filter: str | None):
    files = [f for f in root.rglob("*") if f.is_file() and f.suffix.lower() in
             (".sql", ".pkb", ".pks", ".fnc", ".prc", ".vw", ".trg", ".tab", ".pls", ".plb", ".txt")]
    texts = {}
    for f in files:
        try:
            texts[f] = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass
    pg = Pager(width, lines)
    names = names_filter.split(",") if names_filter else SOURCE_NAMES
    found_idx = []
    for name in names:
        pat = re.compile(r"(CREATE\s+(OR\s+REPLACE\s+)?(EDITIONABLE\s+)?(FUNCTION|PROCEDURE|VIEW|TABLE)\s+(\"?REPADMIN\"?\.)?\"?"
                         + name + r"\"?\b)|(\b(FUNCTION|PROCEDURE)\s+" + name + r"\b)", re.I)
        hit = None
        for f, t in texts.items():
            m = pat.search(t)
            if m:
                hit = (f, m.start())
                break
        if not hit:
            found_idx.append(f"{name}: NOT FOUND")
            continue
        f, pos = hit
        t = texts[f]
        end_m = re.compile(r"\bEND\s+\"?" + name + r"\"?\s*;", re.I).search(t, pos)
        stop = end_m.end() if end_m else min(len(t), pos + 20000)
        if not end_m:
            nxt = re.compile(r"\n\s*(CREATE\s|FUNCTION\s|PROCEDURE\s)", re.I).search(t, pos + 10)
            stop = nxt.start() if nxt else stop
        body = compact_plsql(t[pos:stop])
        found_idx.append(f"{name}: {f.name} line {t.count(chr(10), 0, pos) + 1} ({len(body)} lines)")
        pg.add("SRC", name, body)
    loaders = []
    for tbl in LOADED_TABLES:
        rx = re.compile(r"\b(INSERT\s+INTO|MERGE\s+INTO|UPDATE|DELETE\s+FROM|TRUNCATE\s+TABLE)\s+(\"?REPADMIN\"?\.)?\"?"
                        + tbl + r"\"?\b", re.I)
        for f, t in texts.items():
            for m in rx.finditer(t):
                before = t[:m.start()]
                procs = re.findall(r"\b(?:PROCEDURE|FUNCTION|PACKAGE\s+BODY|TRIGGER)\s+([\w.\"]+)", before, re.I)
                loaders.append(f"{tbl}: {m.group(1).upper()} in {f.name} line {before.count(chr(10)) + 1} "
                               f"({procs[-1] if procs else '?'})")
    pg.sections.insert(0, ("SRC0", "INDEX of needed objects + who writes the LUXIS tables", found_idx + [""] + loaders))
    return pg


# ------------------------------------------------------------------------------------------ export (one .txt back)
AGGREGATE = re.compile(r"\b(GROUP\s+BY|COUNT\s*\(|SUM\s*\(|LISTAGG|APPROX_COUNT_DISTINCT|MIN\s*\(|MAX\s*\()", re.I)


def export_rows(r: dict) -> tuple[str, list[list]]:
    """Rows as they may leave the PC: personal columns masked (also their MIN/MAX), client-level rows of sensitive
    tables dropped, text values of sensitive tables masked unless they are short codes."""
    sql = r["sql"] or ""
    meta = r.get("meta") or {}
    key = meta.get("key") or ["", ""]
    table = key[1] if len(key) > 1 else ""
    sens = bool(SENSITIVE_TABLE.search(table) or SENSITIVE_TABLE.search(sql))
    aggregate = bool(AGGREGATE.search(sql)) and not re.search(r"\bSELECT\s+(\w+\.)?\*", sql, re.I)
    cols = r["columns"] or []
    rows = r["rows"] or []
    if sens and not aggregate:
        return "client-level rows not exported", [[row.get(c) for c in cols if c.upper().startswith("ZZ_")]
                                                   for row in rows[:1]]
    src = {f"{k}_{i}": c for c, k, i in re.findall(r'(?:MIN|MAX)\("((?:[^"]|"")+)"\) AS "(mn|mx)_(\d+)"', sql)}
    if "col" in meta:
        src["v"] = meta["col"]
    out = []
    for row in rows:
        cells = []
        for c in cols:
            v = row.get(c)
            base = src.get(c, c)
            if masked(table, base) or (sens and isinstance(v, str) and c in src
                                       and (len(v) > 12 or NAMEY_COL.search(base))):
                v = "#"
            cells.append(v)
        out.append(cells)
    return "", out


def export_txt(store: Store, out: Path, files: list[str], max_mb: float):
    n = 0
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# from_office explore export {dt.datetime.now().isoformat(timespec='seconds')}\n")
        for ph, stt, k, e in store.stats():
            fh.write(f"# stats {ph} {stt} {k} {int(e or 0)}s\n")
        for (qid,) in store.con.execute("SELECT id FROM q ORDER BY id"):
            r = store.get(qid)
            note, rows = export_rows(r) if r["status"] == "OK" else ("", [])
            rec = {"id": qid, "env": r["env"], "status": r["status"], "purpose": r["purpose"], "total": r["total"],
                   "error": r["error"], "meta": r["meta"], "sql": r["sql"], "columns": r["columns"],
                   "note": note, "rows": rows}
            fh.write("Q " + json.dumps(rec, ensure_ascii=False, default=str) + "\n")
            n += 1
    if files:
        spec = importlib.util.spec_from_file_location("pack_files", HERE.parent / "pack_files.py")
        pack = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(pack)
        tmp = out.with_suffix(".files.tmp")
        pack.main([str(tmp), *files, "--max-mb", str(max_mb)])
        with open(out, "a", encoding="utf-8", newline="\n") as fh:
            fh.write("\n# ==== FILES ====\n")
            fh.write(tmp.read_text(encoding="utf-8"))
        tmp.unlink()
    print(f"{n} query results -> {out}  ({out.stat().st_size / 1024 / 1024:.1f} MB)")


# ------------------------------------------------------------------------------------------ main
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="LUXIS exit Dremio explorer (office PC)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--phase", default="A,B,C,D")
    r.add_argument("--workers", type=int, default=4)
    r.add_argument("--max-minutes", type=float)
    r.add_argument("--client")
    sub.add_parser("status")
    p = sub.add_parser("pages")
    p.add_argument("--section")
    p.add_argument("--lines", type=int, default=55)
    p.add_argument("--width", type=int, default=150)
    p.add_argument("--start", type=int, default=1)
    s = sub.add_parser("source")
    s.add_argument("--root", required=True)
    s.add_argument("--names", help="comma list, default: every object the reports need")
    s.add_argument("--lines", type=int, default=55)
    s.add_argument("--width", type=int, default=150)
    x = sub.add_parser("export")
    x.add_argument("--out", default=str(HERE.parent.parent / "from_office.txt"))
    x.add_argument("--files", nargs="*", default=[], help="folders/files to add (LUXIS source, references, ...)")
    x.add_argument("--max-mb", type=float, default=40.0)
    q = sub.add_parser("sql")
    q.add_argument("id")
    args = ap.parse_args(argv)
    store = Store(DB_PATH)
    if args.cmd == "run":
        mod = load_client(args.client)
        deadline = time.time() + args.max_minutes * 60 if args.max_minutes else None
        run = Runner(mod, store, args.workers, deadline)
        phases = {"A": phase_a, "B": phase_b, "C": phase_c, "D": phase_d}
        for ph in args.phase.split(","):
            print(f"phase {ph}", flush=True)
            phases[ph.strip()](run)
        print("done. Next: python explore.py export")
    elif args.cmd == "status":
        for ph, stt, n, e in store.stats():
            print(f"{ph:<3} {stt:<6} {n:>7}  {int(e or 0)} s")
    elif args.cmd == "pages":
        pg = build_pages(store, args.width, args.lines)
        pages = pg.build(args.section)
        out = HERE / "pages.txt"
        out.write_text("\n\n".join("\n".join(x) for x in pages), encoding="utf-8")
        print(f"{len(pages)} pages (also in {out}); sections: " +
              ", ".join(f"{c} {t[:30]}" for c, t, _ in pg.sections))
        input("press Enter to show page 1 ")
        show_pages(pages, args.start)
    elif args.cmd == "source":
        pg = source_pages(Path(args.root), args.width, args.lines, args.names)
        pages = pg.build()
        (HERE / "source_pages.txt").write_text("\n\n".join("\n".join(x) for x in pages), encoding="utf-8")
        print(f"{len(pages)} pages")
        input("press Enter to show page 1 ")
        show_pages(pages)
    elif args.cmd == "export":
        export_txt(store, Path(args.out), args.files, args.max_mb)
    elif args.cmd == "sql":
        res = store.get(args.id)
        print(json.dumps(res, indent=1, default=str)[:20000] if res else "unknown id")
    return 0


if __name__ == "__main__":
    sys.exit(main())
