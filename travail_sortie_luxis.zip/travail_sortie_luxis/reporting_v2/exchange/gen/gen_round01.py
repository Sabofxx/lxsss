"""Generates reporting_v2/exchange/round_01_requests.txt (kept out of the deliverable)."""
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "round_01_requests.txt"
Q = []          # (group, id, purpose, env, max_rows, sql)
COUNTERS = {}


def add(group, purpose, sql, env="ctlq", max_rows=500, timeout=None):
    COUNTERS[group] = COUNTERS.get(group, 0) + 1
    qid = f"R01_{group}{COUNTERS[group]:03d}"
    Q.append((qid, purpose, env, max_rows, timeout, sql.strip()))
    return qid


IC = "MFGA_INFOCENTRE.DWH"
LX = "LUXIS.REPADMIN"
# Reference parameters already used and proven in the existing projects (CTLQ)
F_BCR = "'280287'"            # BCR mouvements/coupons reference, June 2026
D_FROM, D_TO = "DATE '2026-06-01'", "DATE '2026-07-01'"
LOT_FROM, LOT_TO = 8554978, 8607153   # 280287 window 2026-06-01 -> 2026-07-01 (luxrep_reports)
FUNDS_BCR = "'280287','280299','812645','280499','242013','280421'"
POOL = "'280421'"
TA_FA = "'280273','280274','280268','280605','241582','282303','280334'"

# =====================================================================================
# A. Catalogue (tables and views) - one shot for every source
# =====================================================================================
for src, rows in (("MFGA_INFOCENTRE", 20000), ("MFGI", 20000), ("LUXIS", 20000)):
    add("A", f"catalogue: every table/view under {src}",
        f"""SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE
FROM INFORMATION_SCHEMA."TABLES"
WHERE TABLE_SCHEMA = '{src}' OR TABLE_SCHEMA LIKE '{src}.%'
ORDER BY TABLE_SCHEMA, TABLE_NAME""", max_rows=rows, timeout=1200)
add("A", "catalogue: list of top-level sources/schemas with table counts (all sources)",
    """SELECT TABLE_SCHEMA, COUNT(*) AS N_TABLES
FROM INFORMATION_SCHEMA."TABLES"
GROUP BY TABLE_SCHEMA ORDER BY TABLE_SCHEMA""", max_rows=5000, timeout=1200)
add("A", "catalogue: is an Oracle dictionary (ALL_SOURCE / ALL_VIEWS / USER_SOURCE ...) exposed anywhere? would let us read LUXIS function sources directly",
    """SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE
FROM INFORMATION_SCHEMA."TABLES"
WHERE UPPER(TABLE_NAME) IN ('ALL_SOURCE','USER_SOURCE','DBA_SOURCE','ALL_VIEWS','USER_VIEWS','DBA_VIEWS',
                            'ALL_OBJECTS','ALL_TAB_COLUMNS','ALL_DEPENDENCIES','ALL_TRIGGERS','ALL_MVIEWS')
ORDER BY 1, 2""", timeout=1200)
add("A", "plan B: try reading LUXIS function sources through an Oracle dictionary path (expected to fail if not exposed)",
    """SELECT NAME, TYPE, LINE, TEXT FROM LUXIS.SYS.ALL_SOURCE
WHERE OWNER = 'REPADMIN' AND NAME IN ('GET_FUND_NAME_TB_FDS','GET_NAV_DATE_CALCUL')
ORDER BY NAME, TYPE, LINE""", max_rows=400)
add("A", "Dremio virtual datasets: SQL definition of views over LUXIS / MFGA / MFGI (BUSINESS, FRI, STAGGING ...) that mention REPADMIN tables used by the reports",
    """SELECT TABLE_SCHEMA, TABLE_NAME, SUBSTR(VIEW_DEFINITION, 1, 1500) AS VIEW_DEFINITION_START
FROM INFORMATION_SCHEMA."VIEWS"
WHERE UPPER(VIEW_DEFINITION) LIKE '%REPADMIN%'
   OR UPPER(VIEW_DEFINITION) LIKE '%MFGI.GTA%'
   OR UPPER(VIEW_DEFINITION) LIKE '%AMS_HIS_PTF_VAL_POOL%'
ORDER BY 1, 2""", max_rows=2000, timeout=1200)

# =====================================================================================
# C. Columns - compact (one row per table) then raw plan B for the key tables
# =====================================================================================
for src in ("MFGA_INFOCENTRE", "MFGI"):
    add("C", f"columns of every table under {src}, one row per table (name:type in ordinal order)",
        f"""SELECT TABLE_SCHEMA, TABLE_NAME, COUNT(*) AS N_COLS,
       LISTAGG(COLUMN_NAME || ':' || DATA_TYPE, ',') WITHIN GROUP (ORDER BY ORDINAL_POSITION) AS COLS
FROM INFORMATION_SCHEMA."COLUMNS"
WHERE TABLE_SCHEMA = '{src}' OR TABLE_SCHEMA LIKE '{src}.%'
GROUP BY TABLE_SCHEMA, TABLE_NAME
ORDER BY TABLE_SCHEMA, TABLE_NAME""", max_rows=20000, timeout=1800)

LUXIS_TABLES = """CFA_RECON_SFI_FA DOC_NUM_CDE_TBL_DESCR DOC_NUM_ENTITE DOC_NUM_RELATION DOC_NUM_RELATION_DETAIL
DWH_AMS_CASH_MVT DWH_AMS_DEAL_COUPON_DIVIDEND DWH_AMS_DEAL_FUTURE DWH_AMS_EQUI_FONDS DWH_AMS_HIS_PTF_FRX_RATES
DWH_AMS_HIS_PTF_VAL DWH_AMS_LOT DWH_AMS_MVT DWH_AMS_NAV_ARC_PNL_DELTA DWH_AMS_NAV_ARC_RESULT DWH_AMS_PORTFOLIO
DWH_AMS_SEC_INTL_ID DWH_AMS_SEC_MASTER DWH_AMS_ACC_POS DWH_AMS_ACC_DEF DWH_AMS_ACC_LINK_CHARTS
DWT_GTA_COLL_ACCOUNT DWT_GTA_FUNDS DWT_GTA_MESSAGE DWT_GTA_NAV_SHARE_PRICE DWT_GTA_PTF_SHARE
DWT_GTA_REGISTER DWT_GTA_REG_CONTRACT DWT_GTA_SEC_INTL_ID DWT_GTA_TFC DWT_GTA_CLIENT DWT_GTA_FUND_DELAYDATE
DWT_GTA_ADRESSES_ELEC FONDS_TIERS_PUB_V2 LUXREP_ENVOI LUXREP_QUERIES_FONDS LUXREP_QUERIES_FUTUR_ACCOUNT
LUXREP_QUERIES_GROUPE_EXCLU LUXREP_QUERIES_GROUPE_FONDS LUXREP_QUERIES_GROUPE_UMBRELLA LUXREP_SETUP_DO_CLASS
LUXREP_SETUP_EF_CODE_OPE LUXREP_TA_CODE_OPE LUXREP_TA_CODE_OPE_SETUP LUXREP_TA_PENDING LUXREP_TA_REGISTRES
LUXREP_TA_REGISTRES_BLOCKED LUXREP_TB_FONDS MESI_TRANSACTION_L001 NAV NAV_PARTS NAV_PARTS_MULTI_CCY OP_TA OP_TA_ARC
POS_TA POS_TA_ARC RELATION_ADRESSAGE REPORT_DEFINITION TAB_FND_CPT_AVQ TAB_FND_MAIN TAB_FND_MAIN_BCK TAB_FND_STRUCT
TA_POSITIONS TURNOVER_CORRESP_NUM_FA_TA V_FUND_BACKDATED_FLAG V_DWT_GTA_FUND_DELAYDATE WEBSERVICE_DATA
WKF_FULL_DETAILS_FACTU FUND_PTF_CONSO TBL_TFM GLOBAL_VAR GLOBAL_VARIABLES MFFA_REP_NAV MFFA_REP_NAV_MULTI_CCY
MFFA_REP_NAV_PART MFFA_REP_GENERAL_LEDGER""".split()
add("C", "columns of every LUXIS.REPADMIN table/view read by the reports (incl. TAB_FND_STRUCT, V_DWT_GTA_FUND_DELAYDATE)",
    f"""SELECT TABLE_NAME, COUNT(*) AS N_COLS,
       LISTAGG(COLUMN_NAME || ':' || DATA_TYPE, ',') WITHIN GROUP (ORDER BY ORDINAL_POSITION) AS COLS
FROM INFORMATION_SCHEMA."COLUMNS"
WHERE TABLE_SCHEMA = 'LUXIS.REPADMIN'
  AND TABLE_NAME IN ({",".join("'" + t + "'" for t in LUXIS_TABLES)})
GROUP BY TABLE_NAME ORDER BY TABLE_NAME""", max_rows=500, timeout=1800)
add("C", "columns of every LUXIS.REPADMIN WRK_* / *QUERIES* table: the exact LUXIS output layouts (column order = file order?)",
    """SELECT TABLE_NAME, COUNT(*) AS N_COLS,
       LISTAGG(COLUMN_NAME || ':' || DATA_TYPE, ',') WITHIN GROUP (ORDER BY ORDINAL_POSITION) AS COLS
FROM INFORMATION_SCHEMA."COLUMNS"
WHERE TABLE_SCHEMA = 'LUXIS.REPADMIN'
  AND (TABLE_NAME LIKE 'WRK%' OR TABLE_NAME LIKE '%QUERIES%' OR TABLE_NAME LIKE 'LUXREP%')
GROUP BY TABLE_NAME ORDER BY TABLE_NAME""", max_rows=1000, timeout=1800)
add("C", "columns of every LUXIS table (all schemas), compact: catalogue of what else LUXIS holds (eFront, JSON, MD ...)",
    """SELECT TABLE_SCHEMA, TABLE_NAME, COUNT(*) AS N_COLS,
       SUBSTR(LISTAGG(COLUMN_NAME, ',') WITHIN GROUP (ORDER BY ORDINAL_POSITION), 1, 2000) AS COLS
FROM INFORMATION_SCHEMA."COLUMNS"
WHERE TABLE_SCHEMA LIKE 'LUXIS%'
GROUP BY TABLE_SCHEMA, TABLE_NAME
ORDER BY TABLE_SCHEMA, TABLE_NAME""", max_rows=20000, timeout=1800)
add("C", "plan B (if LISTAGG is refused): raw columns of the key MFGA/MFGI/LUXIS tables",
    """SELECT TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA."COLUMNS"
WHERE (TABLE_SCHEMA = 'MFGA_INFOCENTRE.DWH' AND TABLE_NAME IN
        ('AMS_LOT','AMS_PORTFOLIO','AMS_HIS_PTF_VAL_POOL','AMS_HIS_PTF_VAL','AMS_NAV_ARC_RESULT','AMS_NAV_ARC_PNL_DELTA',
         'AMS_EQUI_FONDS','AMS_NAV_ARC_SHARE_DETAIL','AMS_PTF_SHARE','AMS_DEAL_FUTURE','AMS_HIS_PTF_FRX_RATES'))
   OR TABLE_SCHEMA LIKE 'MFGI.GTA%'
   OR (TABLE_SCHEMA = 'LUXIS.REPADMIN' AND TABLE_NAME IN
        ('NAV','NAV_PARTS','OP_TA','POS_TA','TA_POSITIONS','LUXREP_TB_FONDS','TAB_FND_MAIN','V_FUND_BACKDATED_FLAG'))
ORDER BY 1, 2, 3""", max_rows=20000, timeout=1800)

# =====================================================================================
# W. LUXIS work tables: are recent LUXIS outputs still there? (free extra references with known parameters)
# =====================================================================================
WRK = """WRK_QUERIES_BCR_ACCRUED_EXP WRK_QUERIES_BCR_CASH_DEPOSIT WRK_QUERIES_BCR_CONTAINER WRK_QUERIES_BCR_DIV
WRK_QUERIES_BCR_FUTUR WRK_QUERIES_BCR_FUTUR_DATA WRK_QUERIES_BCR_GD_LIVRE WRK_QUERIES_BCR_MVTS
WRK_QUERIES_BCR_PNL_DELTA WRK_QUERIES_BCR_PTF_NAV WRK_QUERIES_BCR_SH_LG_DATA WRK_QUERIES_BCR_SH_LG_REPORT
WRK_QUERIES_BCR_STAT_IRP WRK_QUERIES_BCR_SUB_RED WRK_QUERIES_BCR_TX_CH_NAV WRK_QUERIES_CRM_FEES
WRK_QUERIES_FA_FEES_RATE WRK_QUERIES_RA_LINEAR_BILL WRK_QUERIES_RA_LINEAR_FEES WRK_QUERIES_TA_CPT_BLOQUE
WRK_QUERIES_TA_IN_OUT WRK_QUERIES_TA_PENDING WRK_QUERIES_TA_POS WRK_QUERIES_TA_REG WRK_QUERIES_TA_SUB_RED
WRK_QUERIES_TA_TFC""".split()
for t in WRK:
    add("W", f"LUXIS work table {t}: first 3 rows with total row count (layout + is anything left from recent runs)",
        f"""SELECT w.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM {LX}.{t} w LIMIT 3""", max_rows=3)
add("W", "LUXIS fund selection per user (LUXREP_QUERIES_FONDS flagged funds = parameters of the runs left in WRK_*)",
    f"""SELECT USER_ID, MAX(DATE_CREATION) AS LAST_CREATION, SUM(CASE WHEN FLAG = 1 THEN 1 ELSE 0 END) AS N_FLAGGED,
       COUNT(*) AS N_ROWS,
       SUBSTR(LISTAGG(CASE WHEN FLAG = 1 THEN FA_NUM END, ',') WITHIN GROUP (ORDER BY FA_NUM), 1, 1000) AS FLAGGED
FROM {LX}.LUXREP_QUERIES_FONDS GROUP BY USER_ID ORDER BY 2 DESC""", max_rows=200)

# =====================================================================================
# F. Fund referential: LUXREP_TB_FONDS / TAB_FND_MAIN / TAB_FND_STRUCT vs AMS_PORTFOLIO / MFGI
# =====================================================================================
add("F", "LUXREP_TB_FONDS: sample (source of the LUXIS fund selector, proc_Fonds) + total",
    f"SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM {LX}.LUXREP_TB_FONDS t ORDER BY FA_NUM LIMIT 20", max_rows=20)
add("F", "LUXREP_TB_FONDS reference funds (BCR + TA test funds)",
    f"SELECT * FROM {LX}.LUXREP_TB_FONDS WHERE FA_NUM IN ({FUNDS_BCR},{TA_FA}) ORDER BY FA_NUM")
add("F", "LUXREP_TB_FONDS profile: counts by FUND_TYPE / LIQUIDATION / ACTIVATION / DE_DROIT",
    f"""SELECT FUND_TYPE, LIQUIDATION, ACTIVATION, DE_DROIT, COUNT(*) AS N, COUNT(DISTINCT FA_NUM) AS N_FUNDS,
       MIN(FA_NUM) AS EX1, MAX(FA_NUM) AS EX2
FROM {LX}.LUXREP_TB_FONDS GROUP BY FUND_TYPE, LIQUIDATION, ACTIVATION, DE_DROIT ORDER BY 1, 2, 3, 4""")
add("F", "TAB_FND_STRUCT sample (structure name of proc_Fonds)",
    f"SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM {LX}.TAB_FND_STRUCT t LIMIT 10", max_rows=10)
add("F", "TAB_FND_MAIN reference funds, all columns (class level)",
    f"SELECT * FROM {LX}.TAB_FND_MAIN WHERE FA_NUM IN ({FUNDS_BCR},{TA_FA}) ORDER BY FA_NUM", max_rows=300)
add("F", "LUXREP_TB_FONDS vs TAB_FND_MAIN: is LUXREP_TB_FONDS a distinct-fund projection of TAB_FND_MAIN? (name/ccy equality counts)",
    f"""WITH tb AS (SELECT FA_NUM, MAX(FUND_NAME) AS N1, MAX(FUND_CCY) AS C1 FROM {LX}.LUXREP_TB_FONDS GROUP BY FA_NUM),
     tf AS (SELECT FA_NUM, MAX(FUND_NAME) AS N2, MIN(FUND_NAME) AS N2B, MAX(FUND_CCY) AS C2 FROM {LX}.TAB_FND_MAIN GROUP BY FA_NUM)
SELECT CASE WHEN tf.FA_NUM IS NULL THEN 'ONLY_TB' WHEN tb.FA_NUM IS NULL THEN 'ONLY_TFM' ELSE 'BOTH' END AS SIDE,
       CASE WHEN tb.N1 = tf.N2 THEN 'NAME_EQ' WHEN tb.N1 = tf.N2B THEN 'NAME_EQ_MIN' ELSE 'NAME_DIFF' END AS NAME_CMP,
       CASE WHEN tb.C1 = tf.C2 THEN 'CCY_EQ' ELSE 'CCY_DIFF' END AS CCY_CMP, COUNT(*) AS N,
       MIN(COALESCE(tb.FA_NUM, tf.FA_NUM)) AS EX
FROM tb FULL OUTER JOIN tf ON tb.FA_NUM = tf.FA_NUM GROUP BY 1, 2, 3 ORDER BY 1, 2, 3""")
add("F", "AMS_PORTFOLIO last lot of reference funds, all columns (look for a long/official name, fund type, father, consolidated flag)",
    f"""SELECT * FROM (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY C_FUND ORDER BY N_LOT DESC) AS RN
FROM {IC}.AMS_PORTFOLIO p WHERE C_FUND IN ({FUNDS_BCR},{TA_FA})) x WHERE RN = 1 ORDER BY C_FUND""")
add("F", "fund name concordance LUXREP_TB_FONDS.FUND_NAME vs AMS_PORTFOLIO.L_FUND (last lot): equal / upper-trim equal / prefix",
    f"""WITH p AS (SELECT C_FUND, L_FUND, C_CCY FROM (SELECT C_FUND, L_FUND, C_CCY,
             ROW_NUMBER() OVER (PARTITION BY C_FUND ORDER BY N_LOT DESC) RN FROM {IC}.AMS_PORTFOLIO) x WHERE RN = 1),
     t AS (SELECT FA_NUM, MAX(FUND_NAME) FUND_NAME, MAX(FUND_CCY) FUND_CCY FROM {LX}.LUXREP_TB_FONDS GROUP BY FA_NUM)
SELECT CASE WHEN p.C_FUND IS NULL THEN 'NOT_IN_MFGA'
            WHEN t.FUND_NAME = p.L_FUND THEN 'EQ'
            WHEN UPPER(TRIM(t.FUND_NAME)) = UPPER(TRIM(p.L_FUND)) THEN 'EQ_CASE_TRIM'
            WHEN POSITION(UPPER(TRIM(p.L_FUND)) IN UPPER(t.FUND_NAME)) > 0 THEN 'MFGA_IN_LUXIS'
            ELSE 'DIFF' END AS NAME_CMP,
       CASE WHEN t.FUND_CCY = p.C_CCY THEN 'CCY_EQ' ELSE 'CCY_DIFF' END AS CCY_CMP,
       COUNT(*) AS N, MIN(t.FA_NUM) AS EX_FUND
FROM t LEFT JOIN p ON p.C_FUND = t.FA_NUM GROUP BY 1, 2 ORDER BY 1, 2""")
add("F", "fund name examples LUXIS vs MFGA (40 funds where they differ)",
    f"""WITH p AS (SELECT C_FUND, L_FUND FROM (SELECT C_FUND, L_FUND,
             ROW_NUMBER() OVER (PARTITION BY C_FUND ORDER BY N_LOT DESC) RN FROM {IC}.AMS_PORTFOLIO) x WHERE RN = 1)
SELECT t.FA_NUM, t.FUND_NAME AS LUXIS_NAME, p.L_FUND AS MFGA_NAME
FROM {LX}.LUXREP_TB_FONDS t JOIN p ON p.C_FUND = t.FA_NUM
WHERE t.FUND_NAME <> p.L_FUND ORDER BY t.FA_NUM LIMIT 40""", max_rows=40)

# =====================================================================================
# N. LUXIS NAV table (NAV_CONTROLE / NAV_PUB / dates) vs AMS_LOT - core of every period type
# =====================================================================================
add("N", "REPADMIN.NAV all columns, 280287 last 15 NAVs",
    f"SELECT * FROM {LX}.NAV WHERE NAV_FUND_NO = {F_BCR} ORDER BY NAV_DATE_NAV DESC LIMIT 15", max_rows=15)
add("N", "AMS_LOT all columns, 280287 lots of June 2026",
    f"SELECT * FROM {IC}.AMS_LOT WHERE C_FUND = {F_BCR} AND D_NAV BETWEEN DATE '2026-06-20' AND {D_TO} ORDER BY N_LOT",
    max_rows=200)
add("N", "REPADMIN.NAV value profile: NAV_CONTROLE x NAV_PUB x NAV_TYP_TRT (2026)",
    f"""SELECT NAV_CONTROLE, NAV_PUB, NAV_TYP_TRT, COUNT(*) AS N, COUNT(DISTINCT NAV_FUND_NO) AS N_FUNDS
FROM {LX}.NAV WHERE NAV_DATE_NAV >= DATE '2026-01-01' GROUP BY 1, 2, 3 ORDER BY 1, 2, 3""")
add("N", "AMS_LOT value profile: C_NAV_TYP x C_TRAIT x validation/dispo filled (2026)",
    f"""SELECT C_NAV_TYP, C_TRAIT, CASE WHEN D_H_VALIDATION_NAV IS NULL THEN 'VAL_NULL' ELSE 'VAL_SET' END AS VAL,
       CASE WHEN D_H_DISPO IS NULL THEN 'DISPO_NULL' ELSE 'DISPO_SET' END AS DISPO, COUNT(*) AS N,
       COUNT(DISTINCT C_FUND) AS N_FUNDS
FROM {IC}.AMS_LOT WHERE D_NAV >= DATE '2026-01-01' GROUP BY 1, 2, 3, 4 ORDER BY 1, 2, 3, 4""")
add("N", "CONCORDANCE NAV vs AMS_LOT per (fund, NAV date) 2026-H1: NAV_CONTROLE/NAV_PUB vs lot attributes of the last lot",
    f"""WITH l AS (SELECT C_FUND, D_NAV, C_NAV_TYP, C_TRAIT, D_H_VALIDATION_NAV, D_H_DISPO, D_H_PROCESS,
              ROW_NUMBER() OVER (PARTITION BY C_FUND, D_NAV ORDER BY N_LOT DESC) RN,
              COUNT(*) OVER (PARTITION BY C_FUND, D_NAV) NL,
              SUM(CASE WHEN C_NAV_TYP = 'O' THEN 1 ELSE 0 END) OVER (PARTITION BY C_FUND, D_NAV) NO
       FROM {IC}.AMS_LOT WHERE D_NAV BETWEEN DATE '2026-01-01' AND DATE '2026-06-30'),
     n AS (SELECT NAV_FUND_NO, NAV_DATE_NAV, NAV_CONTROLE, NAV_PUB FROM {LX}.NAV
           WHERE NAV_DATE_NAV BETWEEN DATE '2026-01-01' AND DATE '2026-06-30')
SELECT n.NAV_CONTROLE, n.NAV_PUB,
       CASE WHEN l.C_FUND IS NULL THEN 'NO_LOT' ELSE 'LOT' END AS HAS_LOT,
       l.C_NAV_TYP AS LAST_TYP, CASE WHEN l.NO > 0 THEN 'HAS_O' ELSE 'NO_O' END AS ANY_O, l.C_TRAIT AS LAST_TRAIT,
       CASE WHEN l.D_H_VALIDATION_NAV IS NULL THEN 'VAL_NULL' ELSE 'VAL_SET' END AS VAL,
       CASE WHEN l.D_H_DISPO IS NULL THEN 'DISPO_NULL' ELSE 'DISPO_SET' END AS DISPO,
       COUNT(*) AS N, MIN(n.NAV_FUND_NO) AS EX_FUND, MAX(n.NAV_DATE_NAV) AS EX_DATE
FROM n LEFT JOIN (SELECT * FROM l WHERE RN = 1) l ON l.C_FUND = n.NAV_FUND_NO AND l.D_NAV = n.NAV_DATE_NAV
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8 ORDER BY 1, 2, 3, 4, 5, 6, 7, 8""", timeout=1800)
add("N", "CONCORDANCE reverse: AMS_LOT (fund, D_NAV) 2026-H1 with no REPADMIN.NAV row, by C_NAV_TYP of last lot",
    f"""WITH l AS (SELECT C_FUND, D_NAV, MAX(C_NAV_TYP) AS T_MAX, MIN(C_NAV_TYP) AS T_MIN FROM {IC}.AMS_LOT
       WHERE D_NAV BETWEEN DATE '2026-01-01' AND DATE '2026-06-30' GROUP BY C_FUND, D_NAV)
SELECT l.T_MIN, l.T_MAX, CASE WHEN n.NAV_FUND_NO IS NULL THEN 'NO_NAV' ELSE 'NAV' END AS IN_NAV, COUNT(*) AS N,
       COUNT(DISTINCT l.C_FUND) AS N_FUNDS, MIN(l.C_FUND) AS EX_FUND
FROM l LEFT JOIN {LX}.NAV n ON n.NAV_FUND_NO = l.C_FUND AND n.NAV_DATE_NAV = l.D_NAV
GROUP BY 1, 2, 3 ORDER BY 1, 2, 3""", timeout=1800)
add("N", "CONCORDANCE NAV_DATE_TRT (calc date) vs AMS_LOT D_H_PROCESS / D_H_VALIDATION_NAV / D_H_DISPO of last O lot (2026-H1)",
    f"""WITH l AS (SELECT C_FUND, D_NAV, D_H_PROCESS, D_H_VALIDATION_NAV, D_H_DISPO,
              ROW_NUMBER() OVER (PARTITION BY C_FUND, D_NAV ORDER BY N_LOT DESC) RN
       FROM {IC}.AMS_LOT WHERE D_NAV BETWEEN DATE '2026-01-01' AND DATE '2026-06-30' AND C_NAV_TYP = 'O')
SELECT CASE WHEN CAST(n.NAV_DATE_TRT AS DATE) = CAST(l.D_H_PROCESS AS DATE) THEN 'TRT=PROCESS'
            WHEN CAST(n.NAV_DATE_TRT AS DATE) = CAST(l.D_H_VALIDATION_NAV AS DATE) THEN 'TRT=VALIDATION'
            WHEN CAST(n.NAV_DATE_TRT AS DATE) = CAST(l.D_H_DISPO AS DATE) THEN 'TRT=DISPO'
            WHEN n.NAV_DATE_TRT IS NULL THEN 'TRT_NULL' ELSE 'TRT_OTHER' END AS TRT_CMP,
       CASE WHEN CAST(n.NAV_DATE_NAV_PUBLICATION AS DATE) = CAST(l.D_H_DISPO AS DATE) THEN 'PUB=DISPO'
            WHEN CAST(n.NAV_DATE_NAV_PUBLICATION AS DATE) = CAST(l.D_H_VALIDATION_NAV AS DATE) THEN 'PUB=VALIDATION'
            WHEN CAST(n.NAV_DATE_NAV_PUBLICATION AS DATE) = CAST(l.D_H_PROCESS AS DATE) THEN 'PUB=PROCESS'
            WHEN n.NAV_DATE_NAV_PUBLICATION IS NULL THEN 'PUB_NULL' ELSE 'PUB_OTHER' END AS PUB_CMP,
       n.NAV_PUB, COUNT(*) AS N, MIN(n.NAV_FUND_NO) AS EX_FUND, MIN(n.NAV_DATE_NAV) AS EX_DATE
FROM {LX}.NAV n JOIN (SELECT * FROM l WHERE RN = 1) l ON l.C_FUND = n.NAV_FUND_NO AND l.D_NAV = n.NAV_DATE_NAV
WHERE n.NAV_DATE_NAV BETWEEN DATE '2026-01-01' AND DATE '2026-06-30'
GROUP BY 1, 2, 3 ORDER BY 1, 2, 3""", timeout=1800)
add("N", "NAV vs AMS_LOT for 280287 side by side (2026-05-25 .. 2026-07-10)",
    f"""SELECT n.NAV_DATE_NAV, n.NAV_CONTROLE, n.NAV_PUB, n.NAV_TYP_TRT, n.NAV_DATE_TRT, n.NAV_DATE_NAV_PUBLICATION,
       l.N_LOT, l.C_NAV_TYP, l.C_TRAIT, l.D_H_PROCESS, l.D_H_VALIDATION_NAV, l.D_H_DISPO
FROM {LX}.NAV n LEFT JOIN {IC}.AMS_LOT l ON l.C_FUND = n.NAV_FUND_NO AND l.D_NAV = n.NAV_DATE_NAV
WHERE n.NAV_FUND_NO = {F_BCR} AND n.NAV_DATE_NAV BETWEEN DATE '2026-05-25' AND DATE '2026-07-10'
ORDER BY n.NAV_DATE_NAV, l.N_LOT""", max_rows=300)
add("N", "Infocentre own copies of LUXIS tables? (MFGA_INFOCENTRE.REPADMIN.NAV seen in old code): sample",
    "SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM MFGA_INFOCENTRE.REPADMIN.NAV t WHERE NAV_FUND_NO = '280287' "
    "ORDER BY NAV_DATE_NAV DESC LIMIT 5", max_rows=5)
add("N", "EFRONT.DATA_FA_CLOSING (union branch of every period function): sample + total, Infocentre path",
    "SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM MFGA_INFOCENTRE.EFRONT.DATA_FA_CLOSING t LIMIT 5", max_rows=5)

# =====================================================================================
# B. Backdated NAV flag (V_FUND_BACKDATED_FLAG / TAB_FND_MAIN.NAV_BACKDATED) - find an MFGA rule
# =====================================================================================
add("B", "V_FUND_BACKDATED_FLAG: profile + the list of backdated funds",
    f"""SELECT NAV_BACKDATED, COUNT(*) AS N,
       SUBSTR(LISTAGG(CASE WHEN NAV_BACKDATED = 1 THEN FUND_NO END, ',') WITHIN GROUP (ORDER BY FUND_NO), 1, 2000) AS FUNDS
FROM {LX}.V_FUND_BACKDATED_FLAG GROUP BY NAV_BACKDATED""")
add("B", "V_FUND_BACKDATED_FLAG all columns, 20 rows (does it carry more than FUND_NO/NAV_BACKDATED?)",
    f"SELECT * FROM {LX}.V_FUND_BACKDATED_FLAG ORDER BY NAV_BACKDATED DESC, FUND_NO LIMIT 20", max_rows=20)
add("B", "CANDIDATE RULE backdated = fund has lots of a non-official NAV type / several lots per NAV date: cross-tab vs flag (2026)",
    f"""WITH l AS (SELECT C_FUND,
              SUM(CASE WHEN C_NAV_TYP = 'O' THEN 1 ELSE 0 END) AS N_O,
              SUM(CASE WHEN C_NAV_TYP <> 'O' THEN 1 ELSE 0 END) AS N_NOT_O,
              COUNT(DISTINCT C_NAV_TYP) AS N_TYPES, MAX(C_NAV_TYP) AS MAX_TYP, MIN(C_NAV_TYP) AS MIN_TYP,
              COUNT(*) AS N_LOTS, COUNT(DISTINCT D_NAV) AS N_DNAV
       FROM {IC}.AMS_LOT WHERE D_NAV >= DATE '2026-01-01' GROUP BY C_FUND)
SELECT b.NAV_BACKDATED, CASE WHEN l.N_NOT_O > 0 THEN 'HAS_NOT_O' ELSE 'ONLY_O' END AS TYPES, l.MIN_TYP, l.MAX_TYP,
       CASE WHEN l.N_LOTS > 3 * l.N_DNAV THEN 'MANY_LOTS_PER_NAV' ELSE 'FEW_LOTS_PER_NAV' END AS DENSITY,
       COUNT(*) AS N, MIN(b.FUND_NO) AS EX
FROM {LX}.V_FUND_BACKDATED_FLAG b JOIN l ON l.C_FUND = b.FUND_NO GROUP BY 1, 2, 3, 4, 5 ORDER BY 1, 2, 3, 4, 5""")
add("B", "AMS_LOT for backdated fund 280499, 2026-06 (how backdating shows in MFGA)",
    f"SELECT * FROM {IC}.AMS_LOT WHERE C_FUND = '280499' AND D_NAV BETWEEN DATE '2026-06-01' AND {D_TO} ORDER BY N_LOT",
    max_rows=300)
add("B", "AMS_PORTFOLIO columns that could carry the backdated flag: last lot of backdated vs non-backdated funds (10 each)",
    f"""WITH b AS (SELECT FUND_NO, NAV_BACKDATED, ROW_NUMBER() OVER (PARTITION BY NAV_BACKDATED ORDER BY FUND_NO) R
             FROM {LX}.V_FUND_BACKDATED_FLAG)
SELECT b.NAV_BACKDATED, p.* FROM (SELECT x.*, ROW_NUMBER() OVER (PARTITION BY C_FUND ORDER BY N_LOT DESC) RN
      FROM {IC}.AMS_PORTFOLIO x) p JOIN b ON b.FUND_NO = p.C_FUND AND b.R <= 10 WHERE p.RN = 1
ORDER BY b.NAV_BACKDATED, p.C_FUND""", max_rows=40)

# =====================================================================================
# E. eFront detection without LUXIS
# =====================================================================================
add("E", "eFront funds: TAB_FND_MAIN.EFRONT x presence in AMS_LOT x presence in MFGA_INFOCENTRE.EFRONT.DATA_FA_CLOSING",
    f"""WITH t AS (SELECT FA_NUM, MAX(EFRONT) AS EFRONT FROM {LX}.TAB_FND_MAIN GROUP BY FA_NUM),
     l AS (SELECT DISTINCT C_FUND FROM {IC}.AMS_LOT WHERE D_NAV >= DATE '2025-01-01'),
     c AS (SELECT DISTINCT FA_NUM FROM MFGA_INFOCENTRE.EFRONT.DATA_FA_CLOSING)
SELECT t.EFRONT, CASE WHEN l.C_FUND IS NULL THEN 'NO_LOT' ELSE 'LOT' END AS IN_MFGA,
       CASE WHEN c.FA_NUM IS NULL THEN 'NO_EF_CLOSING' ELSE 'EF_CLOSING' END AS IN_EF, COUNT(*) AS N, MIN(t.FA_NUM) AS EX
FROM t LEFT JOIN l ON l.C_FUND = t.FA_NUM LEFT JOIN c ON c.FA_NUM = t.FA_NUM
GROUP BY 1, 2, 3 ORDER BY 1, 2, 3""")
add("E", "plan B (if the Infocentre path fails): LUXIS.EFRONT.DATA_FA_CLOSING sample",
    "SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM LUXIS.EFRONT.DATA_FA_CLOSING t LIMIT 5", max_rows=5)

# =====================================================================================
# P. Depooling - AMS_HIS_PTF_VAL_POOL + AMS_LOT, built to last; plus the open questions
# =====================================================================================
add("P", "every (pool, feeder) link in AMS_HIS_PTF_VAL_POOL with first/last D_NAV and row count (full history)",
    f"""SELECT C_FUND AS POOL, C_SUB_FUND AS FEEDER, MIN(D_NAV) AS LINK_FIRST, MAX(D_NAV) AS LINK_LAST,
       COUNT(*) AS N_ROWS, COUNT(DISTINCT D_NAV) AS N_DNAV, MIN(N_LOT) AS LOT_MIN, MAX(N_LOT) AS LOT_MAX
FROM {IC}.AMS_HIS_PTF_VAL_POOL GROUP BY C_FUND, C_SUB_FUND ORDER BY 1, 2""", max_rows=20000, timeout=1800)
add("P", "AMS_HIS_PTF_VAL_POOL all columns, pool 280421 last 2 NAV dates",
    f"""SELECT * FROM {IC}.AMS_HIS_PTF_VAL_POOL WHERE C_FUND = {POOL}
  AND D_NAV >= (SELECT MAX(D_NAV) - 3 FROM {IC}.AMS_HIS_PTF_VAL_POOL WHERE C_FUND = {POOL}) ORDER BY D_NAV, C_SUB_FUND LIMIT 200""")
add("P", "per pool and per feeder: AMS_LOT activity (first/last D_NAV, last lot, lot count since 2023) for every fund present in VAL_POOL",
    f"""WITH f AS (SELECT C_FUND AS F FROM {IC}.AMS_HIS_PTF_VAL_POOL UNION SELECT C_SUB_FUND FROM {IC}.AMS_HIS_PTF_VAL_POOL)
SELECT l.C_FUND, MIN(l.D_NAV) AS FIRST_NAV, MAX(l.D_NAV) AS LAST_NAV, MAX(l.N_LOT) AS LAST_LOT, COUNT(*) AS N_LOTS,
       MAX(CASE WHEN l.C_NAV_TYP = 'O' THEN l.D_NAV END) AS LAST_O_NAV
FROM {IC}.AMS_LOT l WHERE l.C_FUND IN (SELECT F FROM f) GROUP BY l.C_FUND ORDER BY 1""", max_rows=20000, timeout=1800)
add("P", "candidate transfer lot per pool: first pool lot after the last lot of all its (ended) feeders, with its NAV",
    f"""WITH link AS (SELECT C_FUND AS POOL, C_SUB_FUND AS FEEDER, MAX(D_NAV) AS LINK_LAST
              FROM {IC}.AMS_HIS_PTF_VAL_POOL GROUP BY C_FUND, C_SUB_FUND),
     plast AS (SELECT C_FUND, MAX(D_NAV) AS POOL_LAST FROM {IC}.AMS_LOT GROUP BY C_FUND),
     ended AS (SELECT k.POOL, k.FEEDER, k.LINK_LAST FROM link k JOIN plast p ON p.C_FUND = k.POOL
               WHERE p.POOL_LAST > k.LINK_LAST),
     flast AS (SELECT e.POOL, MAX(l.N_LOT) AS FEEDERS_LAST_LOT, MAX(e.LINK_LAST) AS DEPOOL_DATE, COUNT(DISTINCT e.FEEDER) AS N_FEEDERS
               FROM ended e JOIN {IC}.AMS_LOT l ON l.C_FUND = e.FEEDER AND l.D_NAV <= e.LINK_LAST GROUP BY e.POOL)
SELECT f.POOL, f.N_FEEDERS, f.DEPOOL_DATE, f.FEEDERS_LAST_LOT,
       MIN(l.N_LOT) AS TRANSFER_LOT, MIN(l.D_NAV) AS TRANSFER_NAV
FROM flast f LEFT JOIN {IC}.AMS_LOT l ON l.C_FUND = f.POOL AND l.N_LOT > f.FEEDERS_LAST_LOT
GROUP BY f.POOL, f.N_FEEDERS, f.DEPOOL_DATE, f.FEEDERS_LAST_LOT ORDER BY f.DEPOOL_DATE DESC""", max_rows=5000, timeout=1800)
add("P", "OPEN QUESTION: feeders with lots after their depooling (280127, 714902, 740228, 740234, 239602, 253168, 253169, 280202): lots + entries count",
    f"""SELECT l.C_FUND, l.N_LOT, l.D_NAV, l.C_NAV_TYP, l.C_TRAIT, l.D_H_PROCESS,
       (SELECT COUNT(*) FROM {IC}.AMS_CASH_MVT c WHERE c.C_FUND = l.C_FUND AND c.N_LOT = l.N_LOT) AS N_CASH_MVT,
       (SELECT COUNT(*) FROM {IC}.AMS_MVT m WHERE m.C_FUND = l.C_FUND AND m.N_LOT = l.N_LOT) AS N_MVT
FROM {IC}.AMS_LOT l
WHERE l.C_FUND IN ('280127','714902','740228','740234','239602','253168','253169','280202')
  AND l.D_NAV >= DATE '2026-06-01' ORDER BY l.C_FUND, l.N_LOT""", max_rows=2000, timeout=1800)
add("P", "same funds on INTG (frozen 03/07/2026): do the post-depooling lots exist there?",
    f"""SELECT C_FUND, COUNT(*) AS N_LOTS, MIN(D_NAV) AS FIRST_NAV, MAX(D_NAV) AS LAST_NAV, MAX(N_LOT) AS LAST_LOT
FROM {IC}.AMS_LOT WHERE C_FUND IN ('280127','714902','740228','740234','239602','253168','253169','280202')
  AND D_NAV >= DATE '2026-06-01' GROUP BY C_FUND ORDER BY 1""", env="intg")
add("P", "mid-pools (FUND_TYPE 5) and multi-level: funds that are BOTH pool and feeder in VAL_POOL",
    f"""SELECT a.C_FUND AS MIDPOOL, MIN(a.D_NAV) AS AS_POOL_FIRST, MAX(a.D_NAV) AS AS_POOL_LAST,
       MIN(b.C_FUND) AS ITS_POOL, MIN(b.D_NAV) AS AS_FEEDER_FIRST, MAX(b.D_NAV) AS AS_FEEDER_LAST
FROM {IC}.AMS_HIS_PTF_VAL_POOL a JOIN {IC}.AMS_HIS_PTF_VAL_POOL b ON b.C_SUB_FUND = a.C_FUND
GROUP BY a.C_FUND ORDER BY 1""", max_rows=2000, timeout=1800)
add("P", "feeders linked to several pools over time",
    f"""SELECT C_SUB_FUND, COUNT(DISTINCT C_FUND) AS N_POOLS,
       LISTAGG(DISTINCT C_FUND, ',') AS POOLS, MIN(D_NAV) AS FIRST_NAV, MAX(D_NAV) AS LAST_NAV
FROM {IC}.AMS_HIS_PTF_VAL_POOL GROUP BY C_SUB_FUND HAVING COUNT(DISTINCT C_FUND) > 1 ORDER BY 1""", max_rows=2000)
add("P", "PROOF ONLY (not a source): TAB_FND_MAIN_BCK depooling structures, to measure the MFGA detection against them",
    f"""SELECT COALESCE(FA_POOL_NUM, FA_NUM) AS POOL, DEPOOLING_DATE, DEPOOLING_LOT, FUND_TYPE,
       COUNT(*) AS N_CLASSES, COUNT(DISTINCT FA_NUM) AS N_FUNDS,
       SUBSTR(LISTAGG(DISTINCT FA_NUM, ',') WITHIN GROUP (ORDER BY FA_NUM), 1, 600) AS FUNDS
FROM {LX}.TAB_FND_MAIN_BCK GROUP BY 1, 2, 3, 4 ORDER BY 2, 1, 4""", max_rows=2000)
add("P", "LUXIS fund types of every fund present in VAL_POOL (2 feeder, 3 pool, 5 mid-pool): to check the MFGA roles",
    f"""WITH f AS (SELECT C_FUND AS F, 'POOL' AS ROLE FROM {IC}.AMS_HIS_PTF_VAL_POOL
           UNION SELECT C_SUB_FUND, 'FEEDER' FROM {IC}.AMS_HIS_PTF_VAL_POOL)
SELECT f.ROLE, t.FUND_TYPE, COUNT(DISTINCT f.F) AS N, MIN(f.F) AS EX1, MAX(f.F) AS EX2
FROM f LEFT JOIN {LX}.LUXREP_TB_FONDS t ON t.FA_NUM = f.F GROUP BY 1, 2 ORDER BY 1, 2""")
add("P", "AMS_PORTFOLIO pool-related columns (C_CONSOLIDATED, C_FUND_FATHER ...) for pool 280421 and its feeders, last lot",
    f"""SELECT * FROM (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY C_FUND ORDER BY N_LOT DESC) RN FROM {IC}.AMS_PORTFOLIO p
WHERE C_FUND IN ({POOL},'200354','280301','280375','280843','541842')) x WHERE RN = 1""", max_rows=20)
add("P", "TA side of a depooling: share classes of pool 280421 and of feeder 280843 in TAB_FND_MAIN (FA_POOL_NUM, TA_NUM, ISIN)",
    f"SELECT * FROM {LX}.TAB_FND_MAIN WHERE FA_NUM IN ({POOL},'280843','200354') OR FA_POOL_NUM = {POOL} ORDER BY FA_NUM",
    max_rows=200)

# =====================================================================================
# D. LUXIS DWH_AMS_* copies vs MFGA DWH: fingerprint concordance (same fund, same lot window)
# =====================================================================================
COPIES = [  # (luxis copy, mfga table, extra aggregate on a column known on both sides)
    ("DWH_AMS_MVT", "AMS_MVT", "SUM(Q_QTY)"),
    ("DWH_AMS_CASH_MVT", "AMS_CASH_MVT", "SUM(A_MVT)"),
    ("DWH_AMS_DEAL_COUPON_DIVIDEND", "AMS_DEAL_COUPON_DIVIDEND", "SUM(A_NET)"),
    ("DWH_AMS_DEAL_FUTURE", "AMS_DEAL_FUTURE", "SUM(N_CONTRACT)"),
    ("DWH_AMS_HIS_PTF_FRX_RATES", "AMS_HIS_PTF_FRX_RATES", "SUM(R_EXCHANGE_MF)"),
    ("DWH_AMS_HIS_PTF_VAL", "AMS_HIS_PTF_VAL", "COUNT(DISTINCT D_NAV)"),
    ("DWH_AMS_NAV_ARC_RESULT", "AMS_NAV_ARC_RESULT", "COUNT(DISTINCT N_LOT)"),
    ("DWH_AMS_NAV_ARC_PNL_DELTA", "AMS_NAV_ARC_PNL_DELTA", "COUNT(DISTINCT N_LOT)"),
    ("DWH_AMS_EQUI_FONDS", "AMS_EQUI_FONDS", "COUNT(DISTINCT N_LOT)"),
    ("DWH_AMS_LOT", "AMS_LOT", "COUNT(DISTINCT D_NAV)"),
    ("DWH_AMS_PORTFOLIO", "AMS_PORTFOLIO", "COUNT(DISTINCT N_LOT)"),
]
for lx, ic, agg in COPIES:
    add("D", f"CONCORDANCE {lx} (LUXIS) vs {ic} (MFGA), 6 reference funds, lots {LOT_FROM}..{LOT_TO}",
        f"""SELECT 'LUXIS' AS SRC, C_FUND, COUNT(*) AS N, MIN(N_LOT) AS LOT_MIN, MAX(N_LOT) AS LOT_MAX, {agg} AS AGG
FROM {LX}.{lx} WHERE C_FUND IN ({FUNDS_BCR}) AND N_LOT > {LOT_FROM} AND N_LOT <= {LOT_TO} GROUP BY C_FUND
UNION ALL
SELECT 'MFGA', C_FUND, COUNT(*), MIN(N_LOT), MAX(N_LOT), {agg}
FROM {IC}.{ic} WHERE C_FUND IN ({FUNDS_BCR}) AND N_LOT > {LOT_FROM} AND N_LOT <= {LOT_TO} GROUP BY C_FUND
ORDER BY 2, 1""", timeout=1800)
    add("D", f"{lx}: retention of the LUXIS copy (min/max lot and NAV/lot range kept) vs MFGA, fund 280287",
        f"""SELECT 'LUXIS' AS SRC, COUNT(*) AS N, MIN(N_LOT) AS LOT_MIN, MAX(N_LOT) AS LOT_MAX FROM {LX}.{lx} WHERE C_FUND = {F_BCR}
UNION ALL SELECT 'MFGA', COUNT(*), MIN(N_LOT), MAX(N_LOT) FROM {IC}.{ic} WHERE C_FUND = {F_BCR}""", timeout=1800)
add("D", "LUXIS DWH_AMS_SEC_INTL_ID vs MFGA AMS_SECURITIES_INTL_ID: row counts by C_ID_TYP",
    f"""SELECT 'LUXIS' AS SRC, C_ID_TYP, COUNT(*) AS N FROM {LX}.DWH_AMS_SEC_INTL_ID GROUP BY C_ID_TYP
UNION ALL SELECT 'MFGA', C_ID_TYP, COUNT(*) FROM {IC}.AMS_SECURITIES_INTL_ID GROUP BY C_ID_TYP ORDER BY 2, 1""", timeout=1800)
for t in ("AMS_HIS_PTF_VAL", "AMS_NAV_ARC_RESULT", "AMS_NAV_ARC_PNL_DELTA", "AMS_EQUI_FONDS", "AMS_NAV_ARC_SHARE_DETAIL",
          "AMS_PTF_SHARE", "AMS_ACC_POS"):
    add("D", f"MFGA {t}: all columns, fund 280287 last lot of June 2026 (layout for Ptf NAV / Cash deposit / Accrued / P&L delta / Fees rate / TA)",
        f"""SELECT * FROM {IC}.{t} WHERE C_FUND = {F_BCR} AND N_LOT = (SELECT MAX(N_LOT) FROM {IC}.AMS_LOT
   WHERE C_FUND = {F_BCR} AND D_NAV = DATE '2026-06-30') LIMIT 30""", max_rows=30, timeout=900)

# =====================================================================================
# G. TA: LUXIS DWT_GTA_* copies and LUXIS TA tables vs MFGI.GTA
# =====================================================================================
GTA = ["REGISTER", "CLIENT", "REG_CONTRACT", "PTF_SHARE", "FUNDS", "NAV_SHARE_PRICE", "COLL_ACCOUNT", "MESSAGE",
       "SEC_INTL_ID", "TFC", "FUND_DELAYDATE", "ADRESSES_ELEC"]
for g in GTA:
    add("G", f"LUXIS DWT_GTA_{g}: 3 rows + total",
        f"SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM {LX}.DWT_GTA_{g} t LIMIT 3", max_rows=3, timeout=900)
MFGI_CANDIDATES = ["REGISTER", "CLIENT", "REG_CONTRACT", "PTF_SHARE", "FUNDS", "FUND", "NAV_SHARE_PRICE",
                   "COLL_ACCOUNT", "MESSAGE", "SEC_INTL_ID", "TFC", "FUND_DELAYDATE", "REG_POSITION", "ADRESSES_ELEC",
                   "DEAL", "TRANSACTION", "OPERATION", "ORDERS", "POSITION"]
for g in MFGI_CANDIDATES:
    add("G", f"MFGI.GTA.{g} (guessed name; error = does not exist, see catalogue A002): 3 rows + total",
        f"SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM MFGI.GTA.{g} t LIMIT 3", max_rows=3, timeout=900)
add("G", "MFGI.AMS.CODESMSG: profile by language and table (to replace DWT_GTA_MESSAGE / GET_DWT_MESSAGE)",
    """SELECT CLANGUE, COUNT(*) AS N, COUNT(DISTINCT CTABLE) AS N_TABLES FROM MFGI.AMS.CODESMSG GROUP BY CLANGUE ORDER BY 1""")
add("G", "CONCORDANCE DWT_GTA_MESSAGE (last lot) vs MFGI.AMS.CODESMSG on (table, element, label), by table",
    f"""WITH d AS (SELECT C_TABLE, C_ELEMENT, C_LNG, L_LIBELLE FROM (SELECT C_TABLE, C_ELEMENT, C_LNG, L_LIBELLE,
              ROW_NUMBER() OVER (PARTITION BY C_TABLE, C_ELEMENT, C_LNG ORDER BY N_LOT DESC) RN FROM {LX}.DWT_GTA_MESSAGE) x WHERE RN = 1),
     m AS (SELECT DISTINCT TRIM(CTABLE) AS T, TRIM(CELEM) AS E, LIBELLE AS L FROM MFGI.AMS.CODESMSG)
SELECT d.C_TABLE, d.C_LNG, COUNT(*) AS N_DWT, SUM(CASE WHEN m.T IS NOT NULL THEN 1 ELSE 0 END) AS N_SAME_LABEL
FROM d LEFT JOIN m ON m.T = TRIM(d.C_TABLE) AND m.E = TRIM(d.C_ELEMENT) AND m.L = d.L_LIBELLE
WHERE d.C_TABLE IN ('TYPREG','TYPGRP','TYPPERS','REGTYP','SETTLE','COUNTRY','CDELIV','COPER','TCOMM','MONNAIES')
GROUP BY d.C_TABLE, d.C_LNG ORDER BY 1, 2""", timeout=1800)
add("G", "side by side DWT_GTA_MESSAGE vs CODESMSG for table COPER (operation codes), 30 rows",
    f"""SELECT d.C_TABLE, d.C_ELEMENT, d.C_LNG, d.L_LIBELLE, d.L_ABREGE, d.N_LOT, m.CTABLE, m.CELEM, m.CLANGUE, m.LIBELLE
FROM {LX}.DWT_GTA_MESSAGE d LEFT JOIN MFGI.AMS.CODESMSG m ON TRIM(m.CTABLE) = TRIM(d.C_TABLE) AND TRIM(m.CELEM) = TRIM(d.C_ELEMENT)
WHERE d.C_TABLE = 'COPER' ORDER BY d.C_ELEMENT, d.C_LNG, d.N_LOT DESC LIMIT 30""", max_rows=30)
add("G", "MFGI.AMS.CODESMSG: 20 rows of COPER / TYPREG (format of codes and languages)",
    "SELECT * FROM MFGI.AMS.CODESMSG WHERE CTABLE IN ('COPER','TYPREG') ORDER BY CTABLE, CELEM LIMIT 20", max_rows=20)
for t, extra in (("OP_TA", "OPT_OP_DATE"), ("OP_TA_ARC", "OPT_OP_DATE"), ("POS_TA", "PTA_POS_DATE"),
                 ("POS_TA_ARC", "PTA_POS_DATE"), ("TA_POSITIONS", "PTA_S_POS_DATE")):
    add("G", f"LUXIS {t}: 3 rows + total + date range (what feeds it, how far back)",
        f"""SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS, MIN({extra}) OVER () AS ZZ_MIN_DATE, MAX({extra}) OVER () AS ZZ_MAX_DATE
FROM {LX}.{t} t LIMIT 3""", max_rows=3, timeout=1800)
add("G", "LUXIS NAV_PARTS: reference fund 280287 last 10 rows (class-level NAV, used by TA position reports)",
    f"SELECT * FROM {LX}.NAV_PARTS WHERE NAP_FUND_NO = {F_BCR} ORDER BY NAP_DATE_NAV DESC LIMIT 10", max_rows=10)
add("G", "CONCORDANCE NAV_PARTS vs AMS_NAV_ARC_SHARE_DETAIL? sample of the MFGA table for 280287 at 2026-06-30 (columns to align)",
    f"SELECT * FROM {IC}.AMS_NAV_ARC_SHARE_DETAIL WHERE C_FUND = {F_BCR} AND D_NAV = DATE '2026-06-30' LIMIT 20", max_rows=20)
add("G", "TURNOVER_CORRESP_NUM_FA_TA + LUXREP_TA_CODE_OPE + LUXREP_TA_CODE_OPE_SETUP: sizes (config or data?)",
    f"""SELECT 'TURNOVER_CORRESP_NUM_FA_TA' AS T, COUNT(*) AS N FROM {LX}.TURNOVER_CORRESP_NUM_FA_TA
UNION ALL SELECT 'LUXREP_TA_CODE_OPE', COUNT(*) FROM {LX}.LUXREP_TA_CODE_OPE
UNION ALL SELECT 'LUXREP_TA_CODE_OPE_SETUP', COUNT(*) FROM {LX}.LUXREP_TA_CODE_OPE_SETUP
UNION ALL SELECT 'LUXREP_TA_REGISTRES', COUNT(*) FROM {LX}.LUXREP_TA_REGISTRES
UNION ALL SELECT 'LUXREP_TA_REGISTRES_BLOCKED', COUNT(*) FROM {LX}.LUXREP_TA_REGISTRES_BLOCKED""")
for t in ("TURNOVER_CORRESP_NUM_FA_TA", "LUXREP_TA_CODE_OPE", "LUXREP_TA_CODE_OPE_SETUP", "LUXREP_TA_REGISTRES",
          "LUXREP_TA_REGISTRES_BLOCKED"):
    add("G", f"LUXIS {t}: 10 rows", f"SELECT * FROM {LX}.{t} LIMIT 10", max_rows=10)
add("G", "LUXREP_TA_CODE_OPE_SETUP complete (operation-code setup used by Sub/Red TA, In/Out, Comptes bloques)",
    f"SELECT * FROM {LX}.LUXREP_TA_CODE_OPE_SETUP", max_rows=2000)
add("G", "TA fund numbers: TAB_FND_MAIN FA_NUM -> TA_NUM / FA_NUM_IN_TA / PART_TA_CODE / ISIN for the TA test funds",
    f"""SELECT FA_NUM, TA_NUM, FA_NUM_IN_TA, FA_POOL_NUM, PART_FA_CODE, PART_TA_CODE, ISIN_CODE, PART_CCY, FUND_TYPE
FROM {LX}.TAB_FND_MAIN WHERE FA_NUM IN ({TA_FA}) ORDER BY FA_NUM, PART_FA_CODE""", max_rows=300)

# =====================================================================================
# R. Configuration / business tables read by single reports: size + sample
# =====================================================================================
CFG = ["CFA_RECON_SFI_FA", "FONDS_TIERS_PUB_V2", "WEBSERVICE_DATA", "TAB_FND_CPT_AVQ", "LUXREP_QUERIES_FUTUR_ACCOUNT",
       "LUXREP_QUERIES_GROUPE_EXCLU", "LUXREP_QUERIES_GROUPE_FONDS", "LUXREP_QUERIES_GROUPE_UMBRELLA",
       "LUXREP_SETUP_DO_CLASS", "LUXREP_SETUP_EF_CODE_OPE", "LUXREP_TA_PENDING", "LUXREP_ENVOI", "RELATION_ADRESSAGE",
       "REPORT_DEFINITION", "MESI_TRANSACTION_L001", "WKF_FULL_DETAILS_FACTU", "DOC_NUM_ENTITE", "DOC_NUM_RELATION",
       "DOC_NUM_RELATION_DETAIL", "DOC_NUM_CDE_TBL_DESCR", "FUND_PTF_CONSO", "TBL_TFM", "TAB_FND_MAIN_BCK"]
for t in CFG:
    add("R", f"LUXIS {t}: 5 rows + total (what it is, config or data, refreshed when)",
        f"SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM {LX}.{t} t LIMIT 5", max_rows=5, timeout=1200)

# =====================================================================================
# X. Exchange rates used by TA reports (GET_X_RATE_*): candidate MFGA source
# =====================================================================================
add("X", "AMS_HIS_PTF_FRX_RATES for 280287 at 2026-06-30 (all columns, all lots)",
    f"SELECT * FROM {IC}.AMS_HIS_PTF_FRX_RATES WHERE C_FUND = {F_BCR} AND D_NAV = DATE '2026-06-30' ORDER BY C_CCY, N_LOT",
    max_rows=200)
add("X", "MFGA tables whose name suggests FX rates (any schema)",
    """SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA."TABLES"
WHERE (TABLE_SCHEMA LIKE 'MFGA%' OR TABLE_SCHEMA LIKE 'MFGI%' OR TABLE_SCHEMA LIKE 'LUXIS%')
  AND (UPPER(TABLE_NAME) LIKE '%FRX%' OR UPPER(TABLE_NAME) LIKE '%RATE%' OR UPPER(TABLE_NAME) LIKE '%XRATE%'
       OR UPPER(TABLE_NAME) LIKE '%CHANGE%' OR UPPER(TABLE_NAME) LIKE '%CCY%' OR UPPER(TABLE_NAME) LIKE '%CURR%')
ORDER BY 1, 2""", max_rows=2000, timeout=1200)

# =====================================================================================
# M. First NAV page / Multi CCY / Conso: LUXIS tables vs MFGA candidates
# =====================================================================================
add("M", "LUXIS NAV_PARTS_MULTI_CCY: 5 rows (layout, to align with AMS_NAV_ARC_MULTI_CCY in round 2)",
    f"""SELECT * FROM {LX}.NAV_PARTS_MULTI_CCY t WHERE 1 = 1 LIMIT 5""", max_rows=5)
add("M", "AMS_NAV_ARC_MULTI_CCY sample, fund 784810 at 2026-06-29 (all lots)",
    f"SELECT * FROM {IC}.AMS_NAV_ARC_MULTI_CCY WHERE C_FUND = '784810' AND D_NAV = DATE '2026-06-29' ORDER BY N_LOT LIMIT 40",
    max_rows=40)
add("M", "conso: FUND_POOL_REPARTITION (detention % pool -> child) sample, pool 305093",
    f"SELECT * FROM {LX}.FUND_POOL_REPARTITION WHERE FPR_C_FUND_P = '305093' ORDER BY FPR_D_NAV DESC LIMIT 20", max_rows=20)
add("M", "conso: AMS_HIS_PTF_VAL_POOL pool 305093 last NAV, all columns (does MFGA carry the detention % -> replaces FUND_POOL_REPARTITION?)",
    f"""SELECT * FROM {IC}.AMS_HIS_PTF_VAL_POOL WHERE C_FUND = '305093'
  AND D_NAV = (SELECT MAX(D_NAV) FROM {IC}.AMS_HIS_PTF_VAL_POOL WHERE C_FUND = '305093') LIMIT 50""", max_rows=50)
add("M", "LUXIS GLOBAL_VAR complete (GET_GLOBAL_VAR_VALUE used by TA Sub/Red and Positions)",
    f"SELECT * FROM {LX}.GLOBAL_VAR", max_rows=1000)
for t in ("FNP_PARAM_PLAN_CPT", "FNP_PARAM_RUB", "FNP_PARAM_FONDS", "FNP_PARAM_PARTS", "FNP_PARAM_NAV_INI",
          "FNP_PARAM_FREQ", "FUND_BILAN_FONDS", "FUND_CONSO_LISTE", "FUND_BILAN_DET", "FUND_BILAN_ACC",
          "FUND_BILAN_ACC_DET", "FUND_BILAN_ACC_CONSO", "FUND_BILAN_CONSO_METHOD", "MFFA_REP_NAV",
          "MFFA_REP_NAV_MULTI_CCY", "MFFA_REP_NAV_PART"):
    add("M", f"LUXIS {t}: 3 rows + total (config or output table, retention)",
        f"SELECT t.*, COUNT(*) OVER () AS ZZ_TOTAL_ROWS FROM {LX}.{t} t LIMIT 3", max_rows=3, timeout=1200)
add("M", "decoy check: MFGA.DWH vs MFGA_INFOCENTRE.DWH sizes for AMS_LOT (the MFGA.* tables are near-empty copies)",
    f"""SELECT 'MFGA.DWH' AS SRC, COUNT(*) AS N, MAX(D_NAV) AS LAST_NAV FROM MFGA.DWH.AMS_LOT
UNION ALL SELECT 'MFGA_INFOCENTRE.DWH', COUNT(*), MAX(D_NAV) FROM {IC}.AMS_LOT""", timeout=1200)
add("M", "freshness of both environments: last D_NAV and last lot in AMS_LOT (ctlq)",
    f"SELECT MAX(D_NAV) AS LAST_NAV, MAX(N_LOT) AS LAST_LOT, MAX(D_H_PROCESS) AS LAST_PROCESS FROM {IC}.AMS_LOT WHERE D_NAV <= CURRENT_DATE")
add("M", "freshness of both environments: last D_NAV and last lot in AMS_LOT (intg)",
    f"SELECT MAX(D_NAV) AS LAST_NAV, MAX(N_LOT) AS LAST_LOT, MAX(D_H_PROCESS) AS LAST_PROCESS FROM {IC}.AMS_LOT WHERE D_NAV <= CURRENT_DATE",
    env="intg")


def write():
    lines = ["-- round 01 requests (generated). Run on the office PC:",
             "--   python run_round.py round_01_requests.txt",
             f"-- {len(Q)} requests. Groups: A catalogue, C columns, W LUXIS work tables, F funds, N NAV/lots,",
             "--   B backdated, E eFront, P depooling, D LUXIS copies vs MFGA, G TA/MFGI, R config tables, X FX rates",
             ""]
    for qid, purpose, env, max_rows, timeout, sql in Q:
        lines.append(f"-- @id: {qid}")
        lines.append(f"-- @purpose: {purpose}")
        lines.append(f"-- @env: {env}")
        lines.append(f"-- @max_rows: {max_rows}")
        if timeout:
            lines.append(f"-- @timeout: {timeout}")
        lines.append(sql + ";")
        lines.append("")
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(len(Q), "requests ->", OUT)


if __name__ == "__main__":
    write()
